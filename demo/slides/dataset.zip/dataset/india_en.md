# India

| **Republic of India*Bhārat Gaṇarājya*** | |
| --- | --- |
| Horizontal tricolour flag bearing, from top to bottom, deep saffron, white, and green horizontal bands. In the centre of the white band is a navy-blue wheel with 24 spokes. Flag State emblem | |
| **Motto: ***Satyameva Jayate* (Sanskrit)"Truth Alone Triumphs" | |
| **Anthem:** *Jana Gana Mana* (Hindi) "Thou Art the Ruler of the Minds of All People" Duration: 1 minute and 4 seconds. | |
| **National song: *Vande Mataram* (Sanskrit)** "I Bow to Thee, Mother" Duration: 2 minutes and 26 seconds. | |
| Image of a globe centred on India, with India highlighted. Territory controlled by India Territory claimed but not controlled | |
| **Capital** | New Delhi Show location on an interactive map 28°36′50″N 77°12′30″E﻿ / ﻿28.61389°N 77.20833°E |
| **Largest city by city proper population** | Mumbai |
| **Largest city by metropolitan area population** | Delhi |
| **Official languages** |; Hindi; English |
| **Recognised regional languages** | State level and Eighth Schedule |
| **Native languages** | 424 languages |
| **Religion (2011)** |; 79.8% Hinduism; 14.2% Islam; 2.3% Christianity; 1.7% Sikhism; 0.7% Buddhism; 0.4% Jainism; 0.23% unaffiliated; 0.65% other |
| **Demonyms** |; Indian; others |
| **Government** | Federal parliamentary republic |
| **• President** | Droupadi Murmu |
| **• Vice President** | C. P. Radhakrishnan |
| **• Prime Minister** | Narendra Modi |
| **Legislature** | Parliament |
| **• Upper house** | Rajya Sabha |
| **• Lower house** | Lok Sabha |
| **Independence from the United Kingdom** | |
| **• Dominion** | 15 August 1947 |
| **• Republic** | 26 January 1950 |
| **Area** | |
| **• Total** | 3,287,263 km2 (1,269,219 sq mi) (7th) |
| **• Water (%)** | 9.6 |
| **Population** | |
| **• 2026 estimate** | Neutral increase 1.48 billion (1st) |
| **• 2011 census** | Neutral increase 1,210,854,977 (2nd) |
| **• Density** | 434.9/km2 (1,126.4/sq mi) (30th) |
| **GDP (PPP)** | 2026 estimate |
| **• Total** | Increase $18.902 trillion (3rd) |
| **• Per capita** | Increase $12,801 (121st) |
| **GDP (nominal)** | 2026 estimate |
| **• Total** | Increase $4.153 trillion (6th) |
| **• Per capita** | Increase $2,813 (148th) |
| **Gini (2022)** | Positive decrease 25.5 low inequality |
| **HDI (2023)** | Increase 0.685 medium (130th) |
| **Currency** | Indian rupee (₹) (INR) |
| **Time zone** | UTC+05:30 (IST) |
| **Date format** |; dd-mm-yyyy |
| **Calling code** | +91 |
| **ISO 3166 code** | IN |
| **Internet TLD** |.in (others) |

**India**, officially the **Republic of India**, is a country in South Asia. It is the seventh-largest country by area, the most populous country in the world and, since its independence in 1947, the world's most populous democracy. Bounded by the Indian Ocean on the south, the Arabian Sea on the southwest, and the Bay of Bengal on the southeast, it shares land borders with Pakistan to the west; China, Nepal and Bhutan to the north; Bangladesh and Myanmar to the east. In the Indian Ocean, India is near Sri Lanka and the Maldives. Its Andaman and Nicobar Islands share a maritime border with Myanmar, Thailand and Indonesia.

Modern humans arrived on the Indian subcontinent from Africa no later than 55,000 years ago. Their long occupation, predominantly in isolation as hunter-gatherers, has made the region highly diverse. Settled life emerged on the subcontinent in the western margins of the Indus river basin 9,000 years ago, evolving gradually into the Indus Valley Civilisation of the third millennium BCE. By 1200 BCE, an archaic form of Sanskrit, an Indo-European language, had diffused into India from the northwest. Its hymns recorded the early dawnings of Hinduism in India. India's pre-existing Dravidian languages were supplanted in the northern regions. By 400 BCE, caste had emerged within Hinduism, and Buddhism and Jainism had arisen, proclaiming social orders unlinked to heredity. Early political consolidations gave rise to the loose-knit Maurya and Gupta Empires. During this era, there was a flourishing of creativity in art, architecture, and writing, the status of women declined, and untouchability became an organised belief. In South India, the Middle kingdoms exported Dravidian language scripts and religious cultures to the kingdoms of Southeast Asia.

In the 1st millennium Islam, Christianity, Judaism, and Zoroastrianism became established on India's southern and western coasts. Early in the 2nd millennium Muslim armies from Central Asia intermittently overran India's northern plains. The resulting Delhi Sultanate drew northern India into the cosmopolitan networks of medieval Islam. In south India, the Vijayanagara Empire created a long-lasting composite Hindu culture. In the Punjab, Sikhism emerged, rejecting institutionalised religion. The Mughal Empire ushered in two centuries of economic expansion and relative peace, and left a rich architectural legacy. Gradually expanding rule of the British East India Company turned India into a colonial economy but consolidated its sovereignty. British Crown rule began in 1858. The rights promised to Indians were granted slowly, but technological changes were introduced, and modern ideas of education and the public life took root. A nationalist movement emerged in India, the first in the non-European British Empire and an influence on other nationalist movements. Noted for nonviolent resistance after 1920, it became the primary factor in ending British rule. In 1947, the British Indian Empire was partitioned into two independent dominions, a Hindu-majority dominion of India and a Muslim-majority dominion of Pakistan. A large-scale loss of life and an unprecedented migration accompanied the partition.

India has been a federal republic since 1950, governed through a democratic parliamentary system. It is a pluralistic, multilingual and multi-ethnic society. India's population grew from 361 million in 1951 to over 1.4 billion in 2023. During this time, its nominal per capita income increased from US$64 annually to US$2,601, and its literacy rate from 16.6% to 74%. The Indian economy has since become a fast-growing major economy and a hub for information technology, with an expanding middle class. India has reduced its poverty rate, though at the cost of increasing economic inequality. It is a nuclear-weapon state that ranks high in military expenditure. It has disputes over Kashmir with its neighbours, Pakistan and China, unresolved since the mid-20th century. Among the socio-economic challenges India faces are gender inequality, child malnutrition, and rising levels of air pollution. India's land is megadiverse with four biodiversity hotspots. India's wildlife, which has traditionally been viewed with tolerance in its culture, is supported in protected habitats.

## Etymology

According to the *Oxford English Dictionary*, the English proper noun "India" derives most immediately from the Classical Latin *India*, a reference to a loosely-defined historical region of Asia stretching from South Asia to the borders of China. Further etymons are: Hellenistic Greek *India* (Ἰνδία); Ancient Greek *Indos* (Ἰνδός), or the River Indus; Achaemenian Old Persian *Hindu* (an eastern province of the Achaemenid Empire); and Sanskrit *Sindhu*, or "river," but specifically the Indus river, and by extension its well-settled basin. The Ancient Greeks referred to South Asians as *Indoi*, 'the people of the Indus'.

The term *Bharat* (*Bhārat*; pronounced [ˈbʱaːɾət] ⓘ), mentioned in both Indian epic poetry and the Constitution of India, is used in its variations by many Indian languages. A modern rendering of the historical name *Bharatavarsha*, which applied originally to North India, *Bharat* gained increased currency from the mid-19th century as a native name for India.

*Hindustan* ([ɦɪndʊˈstaːn] ⓘ) is a Middle Persian name for India that became popular by the 13th century, and was used widely since the era of the Mughal Empire. The meaning of *Hindustan* has varied, referring to a region encompassing the northern Indian subcontinent (present-day northern India and Pakistan) or to India in its near entirety.

## History

### Ancient India

Based on coalescence of Mitochondrial DNA and Y Chromosome data, it is thought that the earliest extant lineages of anatomically modern humans or *Homo sapiens* on the Indian subcontinent had reached there from Africa between 80,000 and 50,000 years ago, and with high likelihood by 55,000 years ago. Their long occupation, initially in varying forms of isolation as hunter-gatherers, has made the region highly diverse, second only to Africa in human genetic diversity. However, the earliest known modern human fossils in South Asia date to about 30,000 years ago. Evidence for the neolithic period in the western margins of the Indus river basin, at Mehrgarh in Balochistan, Pakistan, dates to after 7000 BCE. Domestication of grain-producing plants (including barley) and animals (including humped zebu cattle) occurred here. These cultures gradually evolved into the Indus Valley Civilisation, which flourished during 2500–1900 BCE in Pakistan and western India. Centred around cities such as Mohenjo-daro, Harappa, Dholavira, Ganweriwala, and Rakhigarhi, its characteristic features included standardised weights, steatite seals, a written script, urban planning, public works, and arts and crafts including pottery styles, terracotta human figures and animal statuettes. Networks of towns and villages grew around the cities in a new agro-pastoral economy.

Between 1500 BCE and 1200 BCE, an archaic form of Sanskrit, an Indo-European language, diffused into India from the northwest. Its evidence today is found in the Rig Veda—the oldest scripture associated with what later became Hinduism—which was composed by Indo-Aryan-speaking tribes migrating east from what is today northern Afghanistan and across the Punjab region. The settling of the Ganges river plain took place during the next millennium, when large swathes of the river system's adjoining regions were deforested, at times by setting fires, or later by employing iron implements, and prepared for agriculture. The settlement may have involved driving the preexisting people out or enslaving them. The Dravidian languages of India were supplanted in the north, creating a broad language family-divide, with the Indo-Aryan languages being spoken mainly in the north and west, and the Dravidian in some parts of east India and most of the south. Classical Sanskrit, a refined and standardised grammatical form would emerge in the mid-1st millennium BCE and was codified in the *Aṣṭādhyāyī* ('Eight chapters') of Pāṇini. The two major Sanskrit epics, the Mahābhārata and the Rāmāyaṇa, however, were composed in a range of oral storytelling registers called Epic Sanskrit which was used in northern India between 400 BCE and 300 CE, and roughly contemporary with classical Sanskrit.

A second urbanisation had taken place in South Asia by 400 BCE, this time on the Ganges plain. In fortified cities, social differentiation by caste, or varna, had emerged. By the mid-millennium two new ethical and social systems had arisen: Jainism based on the teachings of Mahavira and Buddhism on those of the Buddha. Both religions stressed non-violence and abjured animal sacrifices conducted in Brahmanism, and birth into a fixed hereditary *varna*. By living ethically, lay people could rise socially and morally in these religions. Chronicling the life of the Buddha was central to the beginnings of recorded history in India. The rise of the two religions was a backdrop to the emergence of the first loose-knit geographically extensive power in South Asia, the Maurya Empire. During the rule of the founder's grandson, Ashoka (ca. 268–232 BCE), the empire briefly controlled the major urban hubs and arteries of the subcontinent, except in the deep south. The empire's period was notable for creativity in art, architecture, inscriptions, and produced texts, but also for the declining rights of women in the mainstream Indo-Aryan speaking regions. Following his conquest of Kalinga, in which his forces caused immense loss of life, Ashoka adopted Buddhism, subsequently adopting a policy of *dhamma* and commissioning numerous rock and pillar edicts throughout the Maurya Empire to promote ethical conduct, non-violence, and social welfare. As the edicts forbade both the killing of wild animals and the destruction of forests, Ashoka is seen by some modern environmental historians as an early embodiment of that ethos.

By the 4th and 5th centuries, the Gupta Empire had created a complex system of administration and taxation in the greater Ganges Plain; this system became a model for later Indian kingdoms. Under the Guptas, a renewed Hinduism based on devotion, rather than the management of ritual, began to assert itself. The renewal was reflected in a flowering of art, literature, and science. In South India, the Sangam literature of the Tamil language reveals that, between 200 BCE and 200 CE, the southern peninsula was ruled by the Cheras and the Cholas, along the western and eastern plains, respectively, of the Kaveri river valley, and the Pandyas farther south along the Vaigai river valley. By the sixth century, the Pallavas had grown into a regional power. Simultaneously, Buddhism and Jainism, which had favoured a conservative transactionalism, were replaced by kingly devotion to the gods of particular places, which became a characteristic of the Bhakti movement. The Pallavas, in particular, traded extensively with the Roman Empire and with West and Southeast Asia.

### Medieval India

The Indian early medieval age, from 600 to 1200 CE, was defined by regional kingdoms and cultural diversity. No ruler of this period was able to create an empire and consistently control lands much beyond their core region. During this time, pastoral peoples, whose land had been cleared to make way for the growing agricultural economy, were accommodated within caste society, as were new non-traditional ruling classes. The caste system consequently began to show regional differences.

In the 6th and 7th centuries, the first devotional hymns were composed in Tamil. They were imitated all over India and led to both the resurgence of Hinduism and the development of all modern languages of the subcontinent. Indian royalty, big and small, and the temples they patronised drew citizens in significant numbers to the capital cities, which became economic hubs as well. Temple towns of various sizes began to appear everywhere as India underwent another urbanisation. By the 8th and 9th centuries, the effects were felt in Southeast Asia, as South Indian culture and political systems were exported to lands that became part of modern-day Myanmar, Thailand, Laos, Brunei, Cambodia, Vietnam, Philippines, Malaysia, and Indonesia. Indian merchants, scholars, and sometimes armies were involved in this transmission; Southeast Asians took the initiative as well, with many sojourning in Indian seminaries and translating Buddhist and Hindu texts into their languages.

After the 10th century, Muslim Central Asian nomadic clans, using swift-horse cavalry and raising vast armies united by ethnicity, repeatedly overran South Asia's north-western plains, leading eventually to the establishment of the Islamic Delhi Sultanate in 1206. The sultanate was to control much of North India and to make many forays into South India. Although at first disruptive for the Indian elites, the sultanate largely left its vast non-Muslim subject population to its own laws and customs.

By repeatedly repulsing Mongol raiders in the 13th century, the sultanate saved India from the devastation visited on West and Central Asia, setting the scene for centuries of migration of fleeing soldiers, learned men, mystics, traders, artists, and artisans from that region into the subcontinent, thereby creating a syncretic Indo-Islamic culture in the north. The sultanate's raiding and weakening of the regional kingdoms of South India paved the way for the indigenous Vijayanagara Empire. Embracing a strong Shaivite tradition and building upon the military technology of the sultanate, the empire came to control a large portion of peninsular India, and was to influence South Indian society for long afterwards.

### Early modern India

In the early 16th century, northern India, then under mainly Muslim rulers, fell again to the superior mobility and firepower of a new generation of Central Asian warriors. The resulting Mughal Empire did not stamp out the local societies it came to rule. Instead, it balanced and pacified them through new administrative practices and diverse and inclusive ruling elites, leading to more systematic, centralised, and uniform rule. Eschewing tribal bonds and Islamic identity, especially under Akbar, the Mughals united their far-flung realms through loyalty—expressed through a Persianised culture—to an emperor who had near-divine status.

The Mughal state's economic policies, deriving most revenues from agriculture and mandating that taxes be paid in the well-regulated silver currency, caused peasants and artisans to enter larger markets. The relative peace maintained by the empire during much of the 17th century was a factor in India's economic expansion, resulting in greater patronage of painting, literary forms, textiles, and architecture. Newly coherent social groups in northern and western India, such as the Marathas, the Rajputs, and the Sikhs, gained military and governing ambitions during Mughal rule, which, through collaboration or adversity, gave them both recognition and military experience. Expanding commerce during Mughal rule gave rise to new Indian commercial and political elites along the coasts of southern and eastern India. The incremental fragmentation of imperial authority during the late 17th and 18th centuries facilitated a process of decentralisation, enabling provincial elites to assert localised autonomy and consolidate control over their own affairs.

By the early 18th century, with the lines between commercial enterprise and political sovereignty increasingly blurred, European chartered companies—notably the English East India Company—solidified their presence through fortified coastal outposts. The East India Company's control of the seas, greater resources, and more advanced military training and technology led it to assert its military strength increasingly and caused it to become attractive to a portion of the Indian elite; these factors were crucial in allowing the company to gain control over the Bengal region by 1765 and sideline the other European companies. Its further access to the riches of Bengal and the subsequent increased strength and size of its army enabled it to annexe or subdue most of India by the 1820s. India was no longer exporting manufactured goods as it long had, but instead supplying the British Empire with raw materials. Many historians consider this to be the onset of India's colonial period. By this time, with its economic power severely curtailed by the British parliament and having effectively been made an arm of British administration, the East India Company began more consciously to enter non-economic arenas, including education, social reform, and culture.

### Modern India

The appointment in 1848 of Lord Dalhousie as Governor General of the East India Company set the stage for changes essential to a modern state: the consolidation and demarcation of sovereignty, the surveillance of the population, and the education of citizens. Technological changes—among them, railways, canals, and the telegraph—were introduced not long after their introduction in Europe. Disaffection with the company also grew during this time and set off the Indian Rebellion of 1857. Fed by diverse resentments and perceptions, including invasive British-style social reforms, harsh land taxes, and summary treatment of some wealthy landowners and princes, the rebellion rocked many regions of northern and central India and shook the foundations of Company rule. After the rebellion was suppressed in 1858, the East India Company was disbanded, and the British government began to directly administer India. Proclaiming a unitary state and a gradual but limited British-style parliamentary system, the new rulers also protected princes and landed gentry as a feudal safeguard against future unrest. In the decades following, public life gradually emerged across India, eventually leading to the founding of the Indian National Congress in 1885.

The rush of technology and the commercialisation of agriculture in the second half of the 19th century was marked by economic setbacks, and many small farmers became dependent on the whims of faraway markets. There was an increase in the number of large-scale famines, and, despite the risks of infrastructure development borne by Indian taxpayers, little industrial employment was generated for Indians. However, commercial cropping, especially in the newly canalled Punjab, led to increased food production for internal consumption. The railway network provided critical famine relief, notably reduced the cost of moving goods, and helped nascent Indian-owned industry.

After World War I, in which more than 1.3 million Indians served, the Gandhian era began. It was marked by British reforms but also repressive legislation, by more strident Indian calls for self-rule, and by the beginnings of a nonviolent movement of non-co-operation led by Mahatma Gandhi. During the 1930s, the British enacted slow legislative reform; the Indian National Congress won victories in the resulting elections. The next decade was beset with crises: Indian participation in World War II, the Congress's final push for non-co-operation, and an upsurge of Muslim nationalism. All were capped by the advent of independence in 1947, but tempered by the partition of India into two states: India and Pakistan.

India's constitution was adopted in 1950 and established a secular, democratic republic. Economic liberalisation has created a large urban middle class and transformed India into a fast growing economy. However, India has been hamstrung by persistent poverty, both rural and urban; religious- and caste-related violence; Maoist-inspired Naxalite insurgencies; and separatism in Jammu and Kashmir and in Northeast India. India has unresolved territorial disputes with China and with Pakistan.

## Geography

India accounts for the bulk of the Indian subcontinent, lying atop the Indian tectonic plate, and a part of the Indo-Australian Plate. India's defining geologic processes began approximately 70 million years ago, when the Indian Plate, then part of the southern supercontinent Gondwana, began a north-eastward drift caused by seafloor spreading to its south-west, and later, south and south-east. Simultaneously, the vast Tethyan oceanic crust, to its northeast, began to subduct under the Eurasian Plate. The Indian continental crust, however, was obstructed and was sheared horizontally. Its lower crust and mantle slid under, but the upper layer piled up in sheets (or nappes) ahead of the subduction zone. This created the orogeny, or process of mountain building, of the Himalayas. The middle and stiffer layer continued to push into Tibet, causing crustal thickening of the Tibetan Plateau. Immediately south of the emerging Himalayas, plate movement created a vast crescent-shaped trough that rapidly filled with river-borne sediment and now constitutes the Indo-Gangetic Plain. The original Indian plate makes its first appearance above the sediment in the ancient Aravalli range, which extends from the Delhi Ridge in a southwesterly direction. To the west lies the Thar Desert, the eastern spread of which is checked by the Aravallis.

The remaining Indian Plate survives as peninsular India, the oldest and geologically most stable part of India. It extends as far north as the Satpura and Vindhya ranges in central India. These parallel chains run from the Arabian Sea coast in Gujarat in the west to the coal-rich Chota Nagpur Plateau in Jharkhand in the east. To the south, the remaining peninsular landmass, the Deccan Plateau, is flanked on the west and east by coastal ranges known as the Western and Eastern Ghats; the plateau contains the country's oldest rock formations, some over one billion years old. Constituted in such fashion, India lies to the north of the equator between 6° 44′ and 35° 30′ north latitude and 68° 7′ and 97° 25′ east longitude.

Major Himalayan-origin rivers that substantially flow through India include the Ganges and the Brahmaputra, both of which drain into the Bay of Bengal. Important tributaries of the Ganges include the Yamuna and the Kosi. The Kosi's extremely low gradient, caused by long-term silt deposition, leads to severe floods and course changes. Major peninsular rivers, whose steeper gradients prevent their waters from flooding, include the Godavari, the Mahanadi, the Kaveri, and the Krishna, which also drain into the Bay of Bengal; and the Narmada and the Tapti, which drain into the Arabian Sea.

India's coastline measures 7,517 kilometres (4,700 mi) in length; of this distance, 5,423 kilometres (3,400 mi) belong to peninsular India and 2,094 kilometres (1,300 mi) to the Andaman, Nicobar, and Lakshadweep island chains. According to the Indian naval hydrographic charts, the mainland coastline consists of the following: 43% sandy beaches; 11% rocky shores, including cliffs; and 46% mudflats or marshy shores. Coastal features include the marshy Rann of Kutch of western India and the alluvial Sundarbans delta of eastern India; the latter is shared with Bangladesh. India has two archipelagos: the Lakshadweep coral atolls off India's south-western coast; and the Andaman and Nicobar Islands, a volcanic chain in the Andaman Sea.

India has 28 states and 8 union territories.

- A panoramic view of the Garhwal and Kumaon Himalayas. Peaks rising above their surroundings are, among others, Trisul, Nanda Devi, the highest peak entirely within India's borders, and Nanda Kot. The Tibetan Plateau lies behind these mountains, as does the part of the Indus-Yarlung suture zone, the contour along which the Indian Plate has welded to the Eurasian plate. Mount Kailash and Lake Manasarovar in the Tibet Trans-Himalaya—sacred in Hindu and Buddhist mythology—lie immediately behind to the right. The Indus and Yarlung Tsangpo (the upper Brahmaputra river), which mark the western and eastern limits of the Himalaya range, rise near the lake. A panoramic view of the Garhwal and Kumaon Himalayas. Peaks rising above their surroundings are, among others, Trisul, Nanda Devi, the highest peak entirely within India's borders, and Nanda Kot. The Tibetan Plateau lies behind these mountains, as does the part of the Indus-Yarlung suture zone, the contour along which the Indian Plate has welded to the Eurasian plate. Mount Kailash and Lake Manasarovar in the Tibet Trans-Himalaya—sacred in Hindu and Buddhist mythology—lie immediately behind to the right. The Indus and Yarlung Tsangpo (the upper Brahmaputra river), which mark the western and eastern limits of the Himalaya range, rise near the lake.
- The Tungabhadra, with rocky outcrops, flows into the peninsular Krishna River. The Tungabhadra, with rocky outcrops, flows into the peninsular Krishna River.
- The Ganges-Brahmaputra Delta in a Sentinel-3B image. The Ganges to the left, the Brahmaputra to the right. The Ganges-Brahmaputra Delta in a Sentinel-3B image. The Ganges to the left, the Brahmaputra to the right.
- A mangrove tree on a beach on Havelock Island, the Andaman and Nicobar Islands A mangrove tree on a beach on Havelock Island, the Andaman and Nicobar Islands

### Climate

The Indian climate is strongly influenced by the Himalayas and the Thar Desert, both of which drive the economically and culturally pivotal summer and winter monsoons. The Himalayas prevent cold Central Asian katabatic winds from blowing in, keeping the bulk of the Indian subcontinent warmer than most locations at similar latitudes. The Thar Desert plays a crucial role in attracting the moisture-laden south-west summer monsoon winds that, between June and October, provide the majority of India's rainfall.

Four major climatic groupings predominate in India: tropical wet, tropical dry, subtropical humid, and montane. Temperatures in India have risen by 0.7 °C (1.3 °F) between 1901 and 2018. Climate change in India is often thought to be the cause. The retreat of Himalayan glaciers has adversely affected the flow rate of the major Himalayan rivers, including the Ganges and the Brahmaputra. According to some current projections, the number and severity of droughts in India will have markedly increased by the end of the present century.

- Indian coral tree in bloom in the mist of the Southwest Monsoon, Mallalli Falls, Hassan, Karnataka Indian coral tree in bloom in the mist of the Southwest Monsoon, Mallalli Falls, Hassan, Karnataka
- A dromedary in the Thar desert A dromedary in the Thar desert
- New snow in Baspa Valley, Sangla, Himachal Pradesh New snow in Baspa Valley, Sangla, Himachal Pradesh

### Biodiversity

India is a megadiverse country, a term employed for 17 countries that host high biological diversity and contain many species indigenous, or endemic, to them. India is the habitat for 8.6% of all mammals, 13.7% of bird species, 7.9% of reptile species, 6% of amphibian species, 12.2% of fish species, and 6.0% of all flowering plant species. Fully a third of Indian plant species are endemic. India also overlaps four of the world's 34 biodiversity hotspots, or regions that display significant habitat loss in the presence of high endemism.

India's most dense forests, such as the tropical moist forest of the Andaman Islands, the Western Ghats, and Northeast India, occupy approximately 3% of its land area. *Moderately dense forest*, whose canopy density is between 40% and 70%, occupies 9.39% of India's land area. It predominates in the temperate coniferous forest of the Himalayas, the moist deciduous *sal* forest of eastern India, and the dry deciduous teak forest of central and southern India. India has two natural zones of thorn forest, one in the Deccan Plateau, immediately east of the Western Ghats, and the other in the western part of the Indo-Gangetic plain, now turned into rich agricultural land by irrigation, its features no longer visible. Among the Indian subcontinent's notable indigenous trees are the astringent *Azadirachta indica*, or *neem*, which is widely used in rural Indian herbal medicine, and the luxuriant *Ficus religiosa*, or *peepul*, which is displayed on the ancient seals of Mohenjo-daro, and under which the Buddha is recorded in the Pali canon to have sought enlightenment.

Many Indian species have descended from those of Gondwana, the southern supercontinent from which India separated more than 100 million years ago. India's subsequent collision with Eurasia set off a mass exchange of species. However, volcanism and climatic changes later caused the extinction of many endemic Indian forms. Still later, mammals entered India from Asia through two zoogeographic passes flanking the Himalayas. This lowered endemism among India's mammals, which stands at 12.6%, contrasting with 45.8% among reptiles and 55.8% among amphibians. Among endemics are the vulnerable hooded leaf monkey and the threatened Beddome's toad of the Western Ghats.

India contains 172 IUCN-designated threatened animal species, or 2.9% of endangered forms. These include the endangered Bengal tiger and the Ganges river dolphin. Critically endangered species include the gharial, a crocodilian; the great Indian bustard; and the Indian white-rumped vulture, which has become nearly extinct by having ingested the carrion of diclofenac-treated cattle. Before they were extensively used for agriculture and cleared for human settlement, the thorn forests of Punjab were mingled at intervals with open grasslands that were grazed by large herds of blackbuck preyed on by the Asiatic cheetah; the blackbuck, no longer extant in Punjab, is now severely endangered in India, and the cheetah is extinct. The pervasive and ecologically devastating human encroachment of recent decades has critically endangered Indian wildlife. In response, the system of national parks and protected areas, first established in 1935, was expanded substantially. In 1972, India enacted the Wildlife Protection Act and Project Tiger to safeguard crucial wilderness; the Forest Conservation Act was enacted in 1980 and amendments added in 1988. India hosts more than five hundred wildlife sanctuaries and eighteen biosphere reserves, four of which are part of the World Network of Biosphere Reserves; its eighty-nine wetlands are registered under the Ramsar Convention.

- An Attacus taprobanis moth from Kadavoor, Kerala An *Attacus taprobanis* moth from Kadavoor, Kerala
- India has the majority of the world's wild tigers, approximately 3,170 in 2022. India has the majority of the world's wild tigers, approximately 3,170 in 2022.
- A purple sunbird perched on an Indian coral tree, Jim Corbett National Park, Uttarakhand A purple sunbird perched on an Indian coral tree, Jim Corbett National Park, Uttarakhand
- A Crested hawk-eagle with an Indian garden lizard in Satpura National Park, Madhya Pradesh A Crested hawk-eagle with an Indian garden lizard in Satpura National Park, Madhya Pradesh
- Saltwater crocodile in Sundarbans National Park, West Bengal Saltwater crocodile in Sundarbans National Park, West Bengal

## Government and politics

### Politics

India is a parliamentary republic with a multi-party system. There are six recognised national parties in the country, including the Indian National Congress (generally, "the Congress") and the Bharatiya Janata Party (BJP); there are over 50 regional parties. The Congress is considered the ideological centre in Indian political culture; the BJP is right-wing to far-right.

After India's independence on August 15, 1947, Jawaharlal Nehru became prime minister of the Dominion of India, an office he held until January 26, 1950, when India became a republic; Nehru remained the caretaker prime minister until the following year. In the general elections in 1951, 1957, and 1962, the Congress, led by Nehru, won by comfortable margins. After Nehru died in office in May 1964, Lal Bahadur Shastri was unanimously chosen by the Congress to be parliamentary leader, and thus prime minister. After the India–Pakistan war of 1965, Shastri died in January 1966, soon after signing the Tashkent Peace Declaration. The Congress chose Indira Gandhi to be prime minister. She led the party to election victories in 1967 and 1971, the latter a landslide after Pakistan's defeat in the Bangladesh Liberation War. In 1975, Indira Gandhi declared a state of emergency, suspending many civil liberties. Following public discontent with the Emergency, the Congress was voted out of power in 1977; Janata Party, which had opposed the Emergency, was voted in. Its government lasted two years; Morarji Desai and Charan Singh served as prime ministers. The Congress returned to power in 1980. After a military operation against Sikh militants occupying the Golden Temple in Amritsar, Indira Gandhi was assassinated by a Sikh bodyguard on October 31, 1984. She was succeeded as prime minister by Rajiv Gandhi, who led Congress to a comfortable victory in the elections at the end of the year. In 1989, a National Front coalition, led by the Janata Dal, in alliance with the Left Front, won the general elections. The subsequent government lasted just under two years; V. P. Singh and Chandra Shekhar served as prime ministers. In 1991, soon after the first round of polling in the general election, Congress leader Rajiv Gandhi was assassinated by a member of a Sri Lankan Tamil separatist organisation who was seeking to avenge Indian intervention in the Sri Lankan civil war. After the elections, Congress emerged as the largest single party; a new Congress leader, P. V. Narasimha Rao, formed a minority government which served a full five-year term.

In 1996, the BJP briefly formed a government after winning the general election. United Front coalition governments followed, which relied on external political support, H. D. Deve Gowda and I. K. Gujral serving as prime ministers. After the 1998 Indian general election, Atal Bihari Vajpayee of the BJP became prime minister; his government was short-lived due to the lack of a continued mandate. Elections were held again in 1999. The BJP, now a part of the National Democratic Alliance (NDA), formed a coalition government led by Vajpayee, who became the first non-Congress prime minister to complete a five-year term. In the 2004 general election, the NDA was defeated. Congress emerged as the largest single party and formed a coalition, the United Progressive Alliance (UPA). Manmohan Singh, a Sikh, who was proposed by Congress President Sonia Gandhi to be parliamentary leader, served as prime minister of the UPA government, but with some external support. The UPA returned to power in the 2009 general election with increased numbers, no longer dependent on external support. Singh became the first prime minister to be re-elected after Jawaharlal Nehru in 1962. In the 2014 general election, the BJP under Narendra Modi became the first political party since 1984 to win an absolute majority. The party won a larger majority in the 2019 general election. After losing its majority in the 2024 general election, the BJP formed a coalition government with its NDA partners. Modi is the longest-serving non-Congress prime minister. Democratic backsliding was found by the 2026 V-Dem Democracy Report.

### Government

The Constitution of India was drafted by the Constituent Assembly of India with uncommon speed and absence of irregularities between 1946 and 1949. The Government of India Act 1935 was used as a model and framework. Long passages from the Act were included. The constitution describes a federal state with a parliamentary system of democracy. The federal structure was conspicuous for the strength of the central government, which exclusively exercised control of defence, foreign affairs, railways, ports, and currency. The President, the constitutional head of state, has reserve powers for taking over the administration of a state. The central legislature has two houses: the *Lok Sabha*, whose delegates are directly elected by the people in general elections every five years, and the *Rajya Sabha*, whose members are nominated by the elected representatives in the states. There are also features not to be found in the Act of 1935. The definition of fundamental rights is based on the Constitution of the United States, and the constitutional directives, or goals of endeavor, are based on the Constitution of Ireland. An Indian institution recommended by the constitution is the *panchayat* or village committees. Untouchability is illegal (Article 17) and caste distinctions are derecognized (Articles 15(2) and 16(2)). The promulgation of the Indian constitution transformed India into a republic within the Commonwealth.

The prime minister of India is the head of government and exercises most executive power. Appointed by the president, the prime minister is supported by the party or political alliance with a majority of seats in the lower house of parliament. The executive of the Indian government consists of the president, the vice-president, and the Union Council of Ministers—with the cabinet being its executive committee—headed by the prime minister. Any minister holding a portfolio must be a member of one of the houses of parliament. In the Indian parliamentary system, the executive is subordinate to the legislature; the prime minister and their council are directly responsible to the lower house of the parliament. Civil servants act as permanent executives and all decisions of the executive are implemented by them.

India has a three-tier unitary independent judiciary comprising the supreme court, headed by the Chief Justice of India, 25 high courts, and a large number of trial courts. The supreme court has original jurisdiction over cases involving fundamental rights and over disputes between states and the centre and has appellate jurisdiction over the high courts. It has the power to both strike down union or state laws which contravene the constitution and invalidate any government action it deems unconstitutional.

### Administrative divisions

India is a federal union comprising 28 states and 8 union territories. All states, as well as the union territories of Jammu and Kashmir, Puducherry and the National Capital Territory of Delhi, have elected legislatures and governments following the Westminster system. The remaining five union territories are directly ruled by the central government through appointed administrators. In 1956, under the States Reorganisation Act, states were reorganised on a linguistic basis. There are over a quarter of a million local government bodies at city, town, district, block and village levels.

#### States

- Andhra Pradesh
- Arunachal Pradesh
- Assam
- Bihar
- Chhattisgarh
- Goa
- Gujarat
- Haryana
- Himachal Pradesh
- Jharkhand
- Karnataka
- Kerala
- Madhya Pradesh
- Maharashtra
- Manipur
- Meghalaya
- Mizoram
- Nagaland
- Odisha
- Punjab
- Rajasthan
- Sikkim
- Tamil Nadu
- Telangana
- Tripura
- Uttar Pradesh
- Uttarakhand
- West Bengal

#### Union territories

- Andaman and Nicobar Islands
- Chandigarh
- Dadra and Nagar Haveli and Daman and Diu
- Jammu and Kashmir
- Ladakh
- Lakshadweep
- National Capital Territory of Delhi
- Puducherry

### Foreign relations

India remained a member of the Commonwealth of Nations after becoming a republic in 1950. It strongly supported decolonisation in Africa and Asia in the 1950s, and played a leading role in the Non-Aligned Movement. After cordial relations with China during the greater part of the 1950s, India and China went to war in 1962; India was widely thought to have been decisively defeated. By 1967, however, India was able to fend off Chinese excursions into Sikkim.

India has had uneasy relations with its western neighbour, Pakistan. The two went to war in 1947, 1965, 1971, and 1999. Three wars were fought over the disputed territory of Kashmir. After the 1965 war, India began to pursue close military and economic ties with the Soviet Union. By the late 1960s, the Soviet Union was India's largest arms supplier. China's nuclear test of 596 and threats to intervene in support of Pakistan in the 1965 war caused India to produce nuclear weapons. India conducted its first nuclear weapons test in 1974 and carried out additional underground testing in 1998. India has signed neither the Comprehensive Nuclear-Test-Ban Treaty nor the Nuclear Non-Proliferation Treaty, considering both to be flawed and discriminatory. India maintains a "no first use" nuclear policy and is developing a nuclear triad capability as a part of its "Minimum Credible Deterrence" doctrine.

Since the end of the Cold War, India has increased its economic, strategic, and military cooperation with the United States and the European Union. In 2008, a civilian nuclear agreement was signed between India and the United States. Although India possessed nuclear weapons at the time and was not a party to the Nuclear Non-Proliferation Treaty, it received waivers from the International Atomic Energy Agency and the Nuclear Suppliers Group, ending earlier restrictions on India's nuclear technology and commerce; India subsequently signed co-operation agreements involving civilian nuclear energy with Russia, France, the United Kingdom, and Canada.

## Economy

The Indian economy has been among the ten largest economies in the world since 2010. As of 2026, Indian gross domestic output (GDP) have placed the nation as the 6th largest economy in the world. Measured by purchasing power parity (PPP), India is the third-largest economy. It is one of the world's fastest-growing economies with an average annual growth rate exceeding 5% from 1990 to 2010. Demographics strain its economy, with the nation historically maintaining low GDP per capita both regionally and as measured by globally. The vast majority of Indians fall into the global low-income group based on average daily income.

Until 1991, all Indian governments followed protectionist policies that were influenced by socialist economics. Widespread state intervention and regulation largely walled the economy off from the outside world. An acute balance of payments crisis in 1991 forced the nation to liberalise its economy; since then, it has moved increasingly towards a free-market system by emphasising both foreign trade and direct investment inflows. India has been a member of World Trade Organization since 1 January 1995.

The 522-million-worker Indian labour force is the world's second largest, as of 2017. The service sector makes up 55.6% of GDP, the industrial sector 26.3% and the agricultural sector 18.1%. India's foreign exchange remittances of US$100 billion in 2022, the highest in the world, were contributed to its economy by 32 million Indians working in foreign countries. In 2006, the share of external trade in India's GDP stood at 24%, up from 6% in 1985. In 2008, India's share of world trade was 1.6%; in 2021, it was the world's ninth-largest importer and the sixteenth-largest exporter. Between 2001 and 2011, the contribution of petrochemical and engineering goods to total exports grew from 14% to 42%. India was the world's second-largest textile exporter after China in the 2013 calendar year.

Averaging an economic growth rate of 7.5% for several years before 2007, India has more than doubled its hourly wage rates during the first decade of the 21st century. Some 431 million Indians have left poverty since 1985; India's middle classes are projected to number around 580 million by 2030. In 2024, India's consumer market was the world's third largest. India's nominal GDP per capita increased steadily from US$308 in 1991, when economic liberalisation began, to US$1,380 in 2010, to an estimated US$2,731 in 2024. It is expected to grow to US$3,264 by 2026.

- In 2019, 43% of India's total workforce was employed in agriculture. In 2019, 43% of India's total workforce was employed in agriculture.
- A woman growing radish in the foreground and garlic to the right in a village in the Nilgiris, Tamil Nadu. 55% of India's female workforce was employed in agriculture in 2019. A woman growing radish in the foreground and garlic to the right in a village in the Nilgiris, Tamil Nadu. 55% of India's female workforce was employed in agriculture in 2019.
- India is the world's largest producer of milk, with the largest population of cattle. In 2018, nearly 80% of India's milk was sourced from small farms with herd size between one and two, the milk harvested by hand milking. India is the world's largest producer of milk, with the largest population of cattle. In 2018, nearly 80% of India's milk was sourced from small farms with herd size between one and two, the milk harvested by hand milking.

### Industries

The Indian automotive industry, the world's second-fastest growing, increased domestic sales by 26% during 2009–2010, and exports by 36% during 2008–2009. In 2022, India became the world's third-largest vehicle market after China and the United States, surpassing Japan. At the end of 2011, the Indian IT industry employed 2.8 million professionals, generated revenues close to US$100 billion equalling 7.5% of Indian GDP, and contributed 26% of India's merchandise exports.

The pharmaceutical industry in India includes 3,000 pharmaceutical companies and 10,500 manufacturing units; India is the world's third-largest pharmaceutical producer, largest producer of generic medicines, and supplies up to 50–60% of global vaccines demand, contributing up to US$24.44 billion in exports. India's local pharmaceutical market is estimated up to US$42 billion. India is among the top 12 biotech destinations in the world. The Indian biotech industry grew by 15.1% in 2012–2013, increasing its revenues from ₹204.4 billion (Indian rupees) to ₹235.24 billion (US$3.94 billion at June 2013 exchange rates).

India's capacity to generate electrical power is 300 gigawatts, of which 42 gigawatts is renewable. The country's usage of coal is a major cause of India's greenhouse gas emissions, but its renewable energy is growing. India emits about 7% of global greenhouse gas emissions. This equates to about 2.5 tons of carbon dioxide per person per year, which is half the world average. Increasing access to electricity and clean cooking with liquefied petroleum gas have been priorities for energy in India.

- Mumbai, the centre of India's tertiary sector finance industry, also contributes to tourism. Shown here are the Taj Mahal Palace Hotel to the left and the Gateway of India. Mumbai, the centre of India's tertiary sector finance industry, also contributes to tourism. Shown here are the Taj Mahal Palace Hotel to the left and the Gateway of India.
- A tea garden in Sikkim. India, the world's second-largest producer of tea, is a nation of one billion tea drinkers, who consume 70% of India's tea output. A tea garden in Sikkim. India, the world's second-largest producer of tea, is a nation of one billion tea drinkers, who consume 70% of India's tea output.
- A panorama of Bangalore, the centre of India's software development economy. In the 1980s, when the first multinational corporations began to set up centres in India, they chose Bangalore because of the large pool of skilled graduates in the area, in turn due to the many science and engineering colleges in the surrounding region. A panorama of Bangalore, the centre of India's software development economy. In the 1980s, when the first multinational corporations began to set up centres in India, they chose Bangalore because of the large pool of skilled graduates in the area, in turn due to the many science and engineering colleges in the surrounding region.
- A Chinese fishing net being raised in Kochi. Fishing contributes 1.07% to India's total GDP, and supports over 28 million people, especially within vulnerable communities. A Chinese fishing net being raised in Kochi. Fishing contributes 1.07% to India's total GDP, and supports over 28 million people, especially within vulnerable communities.

## Demographics

With an estimated 1,428,627,663 residents in 2023, India is the world's most populous country. 1,210,193,422 residents were reported in the 2011 provisional census report. The median age was 28.7 in 2020. Medical advances made in the last 50 years as well as increased agricultural productivity brought about by the "Green Revolution" have caused India's population to grow rapidly, though India's decennial rates of growth are decreasing: its population grew by 17.64% from 2001 to 2011, compared to 21.54% growth in the previous decade (1991–2001). The first post-colonial census, conducted in 1951, counted 361 million people. The life expectancy at birth has increased from 49.7 years in 1970–1975 to 72.0 years in 2023. The under-five mortality rate for the country was 113 per 1,000 live births in 1994 whereas in 2018 it reduced to 41.1 per 1,000 live births.

The human sex ratio, according to the 2011 census, is 940 females per 1,000 males. Female infanticide in India, and lately female foeticide, have created lop-sided gender ratios; the number of missing women in the country quadrupled from 15 million to 63 million during the period 1964–2014, faster than the population growth during the same period. According to an Indian government study, an additional 21 million girls are unwanted and do not receive adequate care. Despite a government ban on sex-selective foeticide, the practice has far from stopped.

Migration from rural to urban areas has been an important dynamic in India's recent history. The number of people living in urban areas grew by 31.2% between 1991 and 2001. In 2001, over 70% lived in rural areas. The level of urbanisation increased further from 27.81% in the 2001 census to 31.16% in the 2011 census. The slowing down of the overall population growth rate was due to the sharp decline in the growth rate in rural areas since 1991. In the 2011 census, there were 53 million-plus urban agglomerations in India. Among them Mumbai, Delhi, Kolkata, Chennai, Bengaluru, Hyderabad and Ahmedabad, in decreasing order by population.

- The historical development of life expectancy in India from 1881 to 2023 The historical development of life expectancy in India from 1881 to 2023
- The child mortality rate in India from 1960 to 2023 The child mortality rate in India from 1960 to 2023

### Languages

Languages of India belong to several language families. The 2011 Census of India, the last conducted by the Indian government, gives the following breakdown:

| **Language families and speakers in India** | | | | | |
| --- | --- | --- | --- | --- | --- |
| **Serial number** | **Language family** | **Sub-family** | **Number of languages** | **Number of speakers** | **Percentage of speakers** |
| 1 | Indo-European | Indo-Aryan | 21 | 945,052,555 | 78.05% |
| 1 | Indo-European | Iranian | 1 | 21,677 | 0% |
| 1 | Indo-European | Germanic | 1 | 259,678 | 0.02% |
| 2 | Dravidian languages | | 17 | 237,840,116 | 19.64% |
| 3 | Austro-Asiatic | | 14 | 13,493,080 | 1.11% |
| 4 | Tibeto-Burman | | 66 | 12,257,382 | 1.01% |
| 5 | Semito-Hamitic | | 1 | 54,947 | 0% |

There are also small numbers of speakers of Tai–Kadai, Andamanese, and minor language families and isolates.

The official language of India's federal government was chosen by the Constituent Assembly of India in September 1949 after three years of debate between two opposing camps. Hindi language protagonists wanted Hindi in the Devanagari script to be the sole "national language" of India whereas delegates from South India preferred English to have a place in the Constitution. The compromise reached declared (i) Hindi to be the "official language" of India's federal government; (ii) English to be an associate official language for 15 years during which Hindi's formal lexicon would be developed; and (iii) the international form of Hindu–Arabic numerals to be the official numerals. The compromise resolution became articles 343–351 of India's constitution, which came into effect on 26 January 1950. In 1965, after bitter opposition from South India to Hindi becoming the sole official language, a compromise was reached to where English would continue to be an "associate official language" indefinitely.

The Eighth Schedule of India's Constitution also recognises 22 languages, including Hindi but not English, which the government is obligated to develop. These are sometimes called "scheduled languages". This list includes major regional languages, but also others—such as Sanskrit, which no longer has first language speakers in India, and Urdu, which is not region-specific—because of their value to India's cultural heritage. In 1950, there were 14 scheduled languages: Assamese, Bengali, Gujarati, Hindi, Kannada, Kashmiri, Malayalam, Marathi, Oriya, Punjabi, Sanskrit, Tamil, Telugu and Urdu. In the following decades constitutional amendments added others: Sindhi (1967), Nepali, Manipuri, and Konkani (1992), Maithili, Dogri, Santali and Bodo (2004).

- The regions of first-language speech of the main languages of India The regions of first-language speech of the main languages of India
- The main languages of India by relative numbers of speakers The main languages of India by relative numbers of speakers
- On the reverse of each of India's paper money notes, the denomination is listed in a panel on the left in 15 languages, in addition to Hindi and English, which appear more prominently elsewhere. These are from top to bottom: 1. Assamese, 2. Bengali, 3. Gujarati, 4. Kannada, 5. Kashmiri, 6. Konkani, 7. Malayalam, 8. Marathi, 9. Nepali, 10. Oriya, 11. Punjabi, 12. Sanskrit, 13. Tamil, 14. Telugu, 15. Urdu. On the reverse of each of India's paper money notes, the denomination is listed in a panel on the left in 15 languages, in addition to Hindi and English, which appear more prominently elsewhere. These are from top to bottom: 1. Assamese, 2. Bengali, 3. Gujarati, 4. Kannada, 5. Kashmiri, 6. Konkani, 7. Malayalam, 8. Marathi, 9. Nepali, 10. Oriya, 11. Punjabi, 12. Sanskrit, 13. Tamil, 14. Telugu, 15. Urdu.

### Religion

Religion in India is characterised by a diversity of beliefs and practices. Throughout India's history, religion has been an important part of its culture. The Indian subcontinent is the birthplace of four major world religions: Buddhism, Hinduism, Jainism, and Sikhism. India has the largest population of Hindus, Sikhs, and Jains, the third-largest population of Muslims (after Indonesia and Pakistan) and the ninth largest of Buddhists. India also has the largest population of people adhering to both Zoroastrianism (Parsis and Iranis) and the Bahá'í Faith.

The Preamble to the Constitution of India declares India to be a secular state, and freedom of religion to be a fundamental right ("... liberty of thought, expression, belief, faith, and worship.") According to the 2011 census of India, 79.8% of the population of India follows Hinduism, 14.2% Islam, 2.3% Christianity, 1.7% Sikhism, 0.7% Buddhism and 0.4% Jainism. Several tribal religions are also present in India, such as Donyi-Polo, Sanamahism, Sarnaism, and Niamtre.

- Jain pilgrim, Shravanabelagola Jain pilgrim, Shravanabelagola
- The exterior of St Judes Church, Chinnathurai The exterior of St Judes Church, Chinnathurai
- Zoroastrian agiary, Mumbai Zoroastrian agiary, Mumbai
- A Sikh pilgrim at the Golden Temple in Amritsar A Sikh pilgrim at the Golden Temple in Amritsar
- Interior of the Magen David Synagogue, Kolkata Interior of the Magen David Synagogue, Kolkata

### Education

The literacy rate in 2011 was 74.04%: 65.46% among females and 82.14% among males. The rural-urban literacy gap, which was 21.2 percentage points in 2001, dropped to 16.1 percentage points in 2011. The improvement in the rural literacy rate is twice that of urban areas. In 2011 Kerala had the highest literary rate, with 93.91% literacy, and Bihar the lowest, with 63.82%. In 1981 the respective literacy rates for total population, men and women were 41%, 53% and 29%. In 1951, the rates were 18%, 27% and 9%. In 1921, the rates 7%, 12% and 2%. In 1891, they were 5%, 9% and 1%. According to Latika Chaudhary, in 1911 there were under three primary schools for every ten villages. Statistically, more caste and religious diversity reduced private spending. Primary schools taught literacy, so local diversity limited its growth.

The education system of India is the world's second-largest. India has over 900 universities, 40,000 colleges and 1.5 million schools. In India's higher education system, a significant number of seats are reserved under affirmative action policies for the historically disadvantaged. In recent decades India's improved education system is often cited as one of the main contributors to its economic development.

- Children await school lunch in Rayka (also Raika), a village in Gujarat. The salutation Jai Bhim on the blackboard honours the jurist, social reformer, and Dalit leader B. R. Ambedkar. Children await school lunch in Rayka (also Raika), a village in Gujarat. The salutation *Jai Bhim* on the blackboard honours the jurist, social reformer, and Dalit leader B. R. Ambedkar.
- The Madrasah of the Masjid-i-Ala mosque in Srirangapatna, Karnataka, built in the period 1786–87, during the rule of Tipu Sultan. The Madrasah of the Masjid-i-Ala mosque in Srirangapatna, Karnataka, built in the period 1786–87, during the rule of Tipu Sultan.
- IIT Roorkee, formerly the Thomason College of Civil Engineering, is the oldest engineering college in India. It was foundedin 1847 during East India Company rule to train men employed in the construction of the Ganges Canal. IIT Roorkee, formerly the Thomason College of Civil Engineering, is the oldest engineering college in India. It was foundedin 1847 during East India Company rule to train men employed in the construction of the Ganges Canal.

### Health

India bears a disproportionately large burden of the world's tuberculosis rates, with World Health Organization (WHO) statistics for 2022 estimating 2.8 million new infections annually, accounting for 26% of the global total. It is estimated that approximately 40% of the population of India carry tuberculosis infection.

In 2018 chronic obstructive pulmonary disease was the leading cause of death after heart disease. The 10 most polluted cities in the world are all in India with more than 140 million people breathing air 10 times or more over the WHO safe limit. As of 2026, air quality reports show that not a single Indian city meets the WHO's safety guidelines. In cities like Delhi and Mumbai, breathing the air is equivalent to smoking 30 cigarettes a day. In 2017, air pollution killed 1.24 million Indians.

## Culture

### Society

Although sometimes applied to other cultures and religions, caste is a uniquely Indian, and Hindu, social institution. All Hindus fall broadly into four castes, or *varnas*: Brahmin, or priests, at the top; below them Kshatriya, or warriors; further below, Vaishya, or merchants and farmers; and at the bottom, Shudra, or the service class. Outside the caste system, and therefore of traditional Hinduism, lie people formerly called "outcastes" or "untouchables," and now scheduled caste (a term used in India's constitution) or Dalit, a later self-description of pride, meaning "broken" or "downtrodden". Each caste is further divided into sub-castes, or jatis, many of which are tied to occupations. The custom of endogamy, or marrying within one's subcaste, however, makes caste a hereditary label, not of one occupational choice, and has caused the caste system, therefore, to become entrenched. The Constituent Assembly of India abolished untouchability in 1947, the Republic of India did more formally in 1950, and India has since enacted other anti-discriminatory laws and social welfare initiatives related to caste. Still, caste-based inequality, discrimination, segregation, and violence persist.

Multi-generational patrilineal joint families have been the norm in India, though nuclear families are becoming common in urban areas. A very large majority of Indians have their marriages arranged by their parents or family elders. Marriage is thought to be for life; and the divorce rate is extremely low; less than one in a thousand marriages end in divorce. Many women marry before reaching 18, which is their legal marriageable age; child marriages are not uncommon, especially in rural areas. In large parts of Hindu northern India, moreover, a form of territorial exogamy is observed in which a bride marries out of her natal village and her parents do not visit her in her married home; the annual rite raksha bandhan, during which married women return to their natal homes, has served both to affirm bonds with their natal families and offer a recourse in times of marital stress.

- A Gond tribe member during the Dandari festival in Jainoor, Telangana. The Gond religion predates the Hindu synthesis of the mid-first-millennium BCE. A Gond tribe member during the Dandari festival in Jainoor, Telangana. The Gond religion predates the Hindu synthesis of the mid-first-millennium BCE.
- A member of the Ramnami Samaj, a movement among Dalits, whose members worship the Hindu deity Rama and tattoo their bodies with his name A member of the Ramnami Samaj, a movement among Dalits, whose members worship the Hindu deity Rama and tattoo their bodies with his name
- A Hindu bride in Ahmedabad, Gujarat A Hindu bride in Ahmedabad, Gujarat

### Visual art

India has a very ancient tradition of art, which has exchanged many influences with the rest of Eurasia, especially in the first millennium. During this period Buddhist art spread with Indian religions to Central, East and Southeast Asia, the last also greatly influenced by Hindu art. Thousands of seals from the Indus Valley civilisation of the third millennium BCE have been found, usually carved with animals, but also some with human figures. The Pashupati seal, excavated in Mohenjo-daro, Pakistan, in 1928–29, is the best known. Virtually no art survives from a long period following the Indus Valley Civilisation. Almost all surviving ancient Indian art thereafter is in various forms of religious sculpture in durable materials, or coins. There was probably originally far more in wood, which is lost. In north India Mauryan art is the first imperial movement.

Over the following centuries a distinctly Indian style of sculpting the human figure developed, with less interest in articulating precise anatomy than ancient Greek sculpture but showing smoothly flowing forms expressing *prana* ("breath" or life-force). This is often complicated by the need to give figures multiple arms or heads, or represent different genders on the left and right of figures, as with the Ardhanarishvara form of Shiva and Parvati.

Most of the earliest large sculpture is Buddhist, either excavated from Buddhist stupas such as Sanchi, Sarnath and Amaravati, or is rock cut reliefs at sites such as Ajanta, Karla and Ellora. Hindu and Jain sites appear rather later. In spite of this complex mixture of religious traditions, generally, the prevailing artistic style at any time and place has been shared by the major religious groups, and sculptors probably usually served all communities. Gupta art, at its peak c. 300 CE – c. 500 CE, is often regarded as a classical period whose influence lingered for many centuries after; it saw a new dominance of Hindu sculpture, as at the Elephanta Caves. Across the north, this became rather stiff and formulaic after c. 800 CE, though rich with finely carved detail in the surrounds of statues. But in the South, under the Pallava and Chola dynasties, sculpture in both stone and bronze had a sustained period of great achievement; the large bronzes with Shiva as Nataraja have become an iconic symbol of India.

Ancient paintings have only survived at a few sites, of which the crowded scenes of court life in the Ajanta Caves are some of the most important. Painted manuscripts of religious texts survive from Eastern India from 10th century onwards, most of the earliest being Buddhist and later Jain. These significantly influenced later artistic styles. The Persian-derived Deccan painting, starting just before the Mughal miniature, between them give the first large body of secular painting, with an emphasis on portraits, and the recording of princely pleasures and wars. The style spread to Hindu courts, especially among the Rajputs, and developed a variety of styles, with the smaller courts often the most innovative, with figures such as Nihâl Chand and Nainsukh. As a market developed among European residents, it was supplied by Company painting by Indian artists with considerable Western influence. In the 19th century, cheap Kalighat paintings of gods and everyday life, done on paper, were urban folk art from Calcutta, which later saw the Bengal School of Art, reflecting the art colleges founded by the British, the first movement in modern Indian painting.

- Bhutesvara Yakshis, Buddhist reliefs from Mathura, 2nd century CE Bhutesvara Yakshis, Buddhist reliefs from Mathura, 2nd century CE
- Gupta terracotta relief, Krishna Killing the Horse Demon Keshi, 5th century Gupta terracotta relief, *Krishna Killing the Horse Demon Keshi*, 5th century
- Krishna Fluting to the Milkmaids, Kangra painting, 1775–1785 *Krishna Fluting to the Milkmaids*, Kangra painting, 1775–1785
- Chola bronze of Shiva as Nataraja ("Lord of Dance"), Tamil Nadu, 10th or 11th century Chola bronze of Shiva as Nataraja ("Lord of Dance"), Tamil Nadu, 10th or 11th century

### Mathematics

Significant mathematics began in India in the first millennium BCE. The *Śulba Sūtras* (literally, "Aphorisms of the Chords" in Vedic Sanskrit) (c. 700–400 BCE) contain the earliest extant verbal expression of the Pythagorean theorem (although very likely it had been known to the Old Babylonians.) All mathematical works were orally transmitted until approximately 500 BCE; thereafter, they were transmitted both orally and in manuscript form. The oldest extant mathematical document produced on the Indian subcontinent is the birch bark Bakhshali manuscript from the 7th century CE.

In the classical period of Indian mathematics (400 CE to 1200 CE), important contributions were made by Aryabhata, Brahmagupta, Bhaskara II, Varāhamihira, and Madhava. The decimal number system in use today was first recorded in Indian mathematics. Indian mathematicians made early contributions to the study of the concept of zero as a number, negative numbers, arithmetic, and algebra. Trigonometry was further advanced in India, and the modern definitions of sine and cosine were developed there. These mathematical concepts were transmitted to the Middle East, China, and Europe. A later landmark in Indian mathematics was the development of the series expansions for trigonometric functions (sine, cosine, and arc tangent) by mathematicians of the Kerala school in the 15th century CE. Their work, completed two centuries before the invention of calculus in Europe, provided the first example of a power series. In the modern era Srinivasa Ramanujan made fundamental contributions to number theory.

### Music

India contains a wide array of musical practices, including many different folk musics from different regions. Indian classical music has Vedic origins, and split in the 13th century into the two main traditions of Hindustani and Carnatic music. Hindustani is associated with North India and is more improvisational, featuring instruments such as the sitar and tabla, and Carnatic is South Indian and more focused on written compositions such as the *kriti*, while both styles contain common elements such as the raga melodic framework and tala rhythmic meter. Indian music has influenced western genres, including rock and jazz musicians during the 1960s counterculture.

Indian film music is music written for Indian cinema, generally composed by music directors and sung by playback singers. Modern Indian pop takes influences from classical, folk, and western pop music.

- M. S. Subbulakshmi, Carnatic music vocalist M. S. Subbulakshmi, Carnatic music vocalist
- Carnatic music mridangam player Palghat Mani Iyer (left), with violinists, l. to r.: L. Vaidyanathan, L. Subramaniam, and L. Shankar. Carnatic music mridangam player Palghat Mani Iyer (left), with violinists, l. to r.: L. Vaidyanathan, L. Subramaniam, and L. Shankar.
- Allauddin Khan, Hindustani classical music sarod player and teacher Allauddin Khan, Hindustani classical music sarod player and teacher
- Ravi Shankar playing the sitar at the Woodstock music festival, 1972 Ravi Shankar playing the sitar at the Woodstock music festival, 1972

### Dance

Dance in India has drawn heavily from Indian classical dance traditions. Many of these in turn arose in temples or other religious contexts. Their sponsorship and promotion, however, has continued in secular, modern India. India also has local and modern dance traditions. Whether a dance is classical is determined by the Sangeet Natak Academi, the Indian government's organisation for performing arts. Although more dances could perhaps meet the criteria for classical, the Akademi has chosen eight.

| **Classical Dances of India** | | | | | |
| --- | --- | --- | --- | --- | --- |
| **Serial number** | **Dance** | **Indigenous to: State** | **Region** | **Type or origin** | **Musical accompaniment** |
| 1 | Bharatanatyam | Tamil Nadu | South India | Temple dance | Cinna Melam, Carnatic music |
| 2 | Kathak | Uttar Pradesh | North India | Court dance | Hindustani music |
| 3 | Kathakali | Kerala | South India | Dance-drama | Madhalam drum ensembles; Sopana vocal music |
| 4 | Kuchipudi | Andhra Pradesh | South India | Dance-drama | Carnatic music ensemble |
| 5 | Manipuri | Manipur | Northeast India | Temple/ritual dance | Ensemble comprising Pung Cholom, flutes, trumpets, Tambura, Pena, and cymbals |
| 6 | Mohiniattam | Kerala | South India | Dance-drama | Carnatic ensemble |
| 7 | Odissi | Odisha | East India | Temple dance | Ensemble of Hindustani music instruments: pakhavaj, sitar, flute, cymbals, harmonium |
| 8 | Sattriya | Assam | Northeast India | Dance-drama | Borgeet accompanied by khol drums and cymbals. |

The best-known classical dance is Bharatnatyam, which began in the temple dances of Tamil devadasis. Identified with "prostitutes and courtesans", their dancing was formally banned in 1947. Concurrently, the dance was rehabilitated as a "pure" art form, with Rukmini Devi Arundale as a prominent figure. A devdasi who went on to attain national and international prominence was Thanjavur Balasaraswati. Some sources consider the dance-dramas Chhau of Jharkhand, West Bengal, and Odisha and Yakshagana of Karnataka to also belong to the classical tradition.

Local dance traditions vary widely across India. In addition to the dance-dramas Chhau and Yakshagana, they include dance-dramas Raslila of western Uttar Pradesh and Terukkuttu of Tamil Nadu; calendrical and festival dances such as the Bhangra of Punjab, especially at Vaisakhi, the onset of spring, and Garba of Gujarat during Navratri; and tribal or Adivasi dances, such as those of the Santal and Toda people, the latter, for example, in honour of the god Ön who brought buffalo to earth.

Among 20th-century directions is the modern dance of Uday Shankar in which classical styles were employed but not adhered to rigidly. Examples are dance-dramas based on the ancient Indian animal fables, *Panchatantra*, and Nehru's mid-century meditation on Indian history, *The Discovery of India*. Dance has been an essential aspect of Indian films from the first talkies of the 1930s. The individual and group dances of Bollywood, for example, show a broad range of influences, including classical, local, and Western popular dance. Towards the end of the 20th century, innovations in British South Asian music and dance, such as Post-Bhangra, fed back into dance in India.

- The Kathakali dance of Kerala The *Kathakali* dance of Kerala
- The Bharatanatyam dance of Tamil Nadu The *Bharatanatyam* dance of Tamil Nadu
- The Kathak dance of northern India absorbed Persian and Central Asian influences during Mughal rule. The *Kathak* dance of northern India absorbed Persian and Central Asian influences during Mughal rule.

### Clothing

From ancient times until the advent of the modern, the most widely worn traditional dress in India was draped. For women it took the form of a sari, a single piece of cloth many yards long. The sari was traditionally wrapped around the lower body and the shoulder. In its modern form, it is combined with an underskirt, or Indian petticoat, and tucked in along the waist band for more secure fastening. It is also commonly worn with an Indian blouse, or choli, which serves as the primary upper-body garment, the sari's end—passing over the shoulder—covering the midriff and obscuring the upper body's contours. For men, a similar but shorter length of cloth, the dhoti, has served as a lower-body garment.

The use of stitched clothes became widespread after Muslim rule was established by the Delhi sultanate (c. 1300 CE) and continued by the Mughal Empire (c. 1525 CE). Among the garments introduced during this time and still commonly worn are: the shalwars and pyjamas, both styles of trousers, and the tunics kurta and kameez. Shalwars are atypically wide at the waist but narrow to a cuffed bottom. They are held up by a drawstring, which causes them to become pleated around the waist. When the pants are cut quite narrow, on the bias, they are called churidars. The kameez is a long shirt or tunic. Its side seams left open below the waistline. The kurta is traditionally collarless and made of cotton or silk; it is worn plain or with embroidered decoration, such as chikankari; and typically falls to either just above or just below the wearer's knees.

In the last 50 years, fashions have changed a great deal in India. Increasingly, in urban northern India, the sari is no longer the apparel of everyday wear, though they remain popular on formal occasions. The traditional shalwar kameez is rarely worn by younger urban women, who favour churidars or jeans. In office settings, ubiquitous air conditioning allows men to wear sports jackets year-round. For weddings and formal occasions, men in the middle and upper classes often wear bandhgala, or short Nehru jackets, with pants, with the groom and his groomsmen sporting sherwanis and churidars.

- A man in dhoti and woollen shawl in Varanasi A man in dhoti and woollen shawl in Varanasi
- Female tourists from Manipur in shawl and phanek—lower-body garment similar to a sarong Female tourists from Manipur in shawl and phanek—lower-body garment similar to a sarong
- Women in shalwar-kameez in Puducherry Women in shalwar-kameez in Puducherry

### Cuisine

The foundation of a typical Indian meal is a cereal cooked plainly and complemented with savoury dishes. The cooked cereal could be steamed rice; chapati, a thin unleavened bread; idli, a steamed breakfast cake; or dosa, a griddled pancake. The savoury dishes might include lentils, pulses, vegetables, meat, poultry and fish commonly spiced with ginger and garlic, but also coriander, cumin, turmeric, cinnamon, cardamom and others. In some instances, the ingredients may be mixed during the cooking process. India has distinctive vegetarian cuisines, each a feature of the geographical and cultural histories of its adherents. About 20% to 39% of India's population consists of vegetarians. Although meat is eaten widely, the proportional consumption of meat is low.

The most significant import of cooking techniques into India during the last millennium occurred during the Mughal Empire, spreading into northern India from regions to its northwest, along with dishes such as pilaf. Onions, garlic, almonds, and spices were added to the simple yogurt marinade of Persia. Rice was partially cooked and layered alternately with sauteed meat, the pot sealed tightly, and slow cooked according to another Persian cooking technique, to produce biryani, a feature of festive dining in many parts of India.

The diversity of Indian food served worldwide has been partially concealed by the dominance of Punjabi cuisine. The popularity of tandoori chicken—cooked in a tandoor oven, which had traditionally been used for baking bread in the rural Punjab and the Delhi region, especially among Muslims, but which is originally from Central Asia—dates to the 1950s, and was caused in large part by an entrepreneurial response among people from the Punjab who had been displaced by the 1947 partition.

- South Indian vegetarian thali, or platter South Indian vegetarian thali, or platter
- Machher jhol, a spicy fish curry eaten in eastern India, Nepal, and Bangladesh Machher jhol, a spicy fish curry eaten in eastern India, Nepal, and Bangladesh
- Mango, the national fruit of India, is eaten widely in the summer months. Mango, the national fruit of India, is eaten widely in the summer months.

### Sports

Several traditional indigenous sports such as *kabaddi*, *kho kho*, *pehlwani* and *gilli-danda*, and also martial arts, such as *Kalarippayattu* and *marma adi* remain popular. Chess is commonly held to have originated in India as *chaturaṅga*; There has been a rise in the number of Indian grandmasters. Viswanathan Anand became the undisputed Chess World Champion in 2007 and held the status until 2013. Parcheesi is derived from *Pachisi* another traditional Indian pastime, which in early modern times was played on a giant marble court by Mughal emperor Akbar.

Cricket is the most popular sport in India. India is one of the more successful cricket teams, having won two Cricket World Cups, three T20 World Cups, and three Champions Trophies. India has won a record eight field hockey gold medals in the summer Olympics.

- The Indian hockey team, captained by Dhyan Chand (standing second from l.), after winning the finals at the 1936 Summer Olympics – their third of six consecutive Olympic golds The Indian hockey team, captained by Dhyan Chand (standing second from l.), after winning the finals at the 1936 Summer Olympics – their third of six consecutive Olympic golds
- Gukesh Dommaraju, the reigning world chess champion Gukesh Dommaraju, the reigning world chess champion
- Indian cricket player Sachin Tendulkar, the highest run-getter in test cricket, playing a defensive stroke against Australia in Bangalore, 2010 Indian cricket player Sachin Tendulkar, the highest run-getter in test cricket, playing a defensive stroke against Australia in Bangalore, 2010

## See also

- Outline of India

## Notes

1. Originally written in Sanskritised Bengali and adopted as the national anthem in its Hindi translation
1. Written in a mixture of Sanskrit and Sanskritised Bengali
1. "[...] *Jana Gana Mana* is the National Anthem of India, subject to such alterations in the words as the Government may authorise as occasion arises; and the song *Vande Mataram*, which has played a historic part in the struggle for Indian freedom, shall be honoured equally with *Jana Gana Mana* and shall have equal status with it."
1. According to Part XVII of the Constitution of India, Hindi in the Devanagari script is the official language of the Union, along with English as an additional official language. States and union territories can have a different official language of their own other than Hindi or English.
1. Not all the state-level official languages are in the eighth schedule and not all the scheduled languages are state-level official languages. For example, the Sindhi language is an 8th scheduled but not a state-level official language.
1. Kashmiri and Dogri language are the official languages of Jammu and Kashmir which is currently a union territory and no longer the former state.
 - According to Ethnologue, there are 426 living indigenous languages in India, in contrast to 11 extinct indigenous languages. In addition, there are 32 living non-indigenous languages.
 - Different sources give widely differing figures, primarily based on how the terms "language" and "dialect" are defined and grouped.

1. "The country's exact size is subject to debate because some borders are disputed. The Indian government lists the total area as 3,287,260 km2 (1,269,220 sq mi) and the total land area as 3,060,500 km2 (1,181,700 sq mi); the United Nations lists the total area as 3,287,263 km2 (1,269,219 sq mi) and total land area as 2,973,190 km2 (1,147,960 sq mi)."
1. See Date and time notation in India.
1. ISO 15919: *Bhārat Gaṇarājya*
1. The Government of India also regards Afghanistan as a bordering country, as it considers all of Kashmir to be part of India. However, this is disputed, and the region bordering Afghanistan is administered by Pakistan.
1. "A Chinese pilgrim also recorded evidence of the caste system as he could observe it. According to this evidence the treatment meted out to untouchables such as the Chandalas was very similar to that which they experienced in later periods. This would contradict assertions that this rigid form of the caste system emerged in India only as a reaction to the Islamic conquest."
1. "All these achievements are dwarfed, though, by the Sanskrit linguistic tradition culminating in the famous grammar by Pāṇini, known as the Aṣṭhādhyāyī. The elegance and comprehensiveness of its architecture have yet to be surpassed by any grammar of any language, and its ingenious methods of stratifying out use and mention, language and metalanguage, and theorem and metatheorem predate key discoveries in western philosophy by millennia."
1. the historic religion of the Vedas, and the precursor to Hinduism
1. The Mauryan economy was helped by the rise of Buddhism and Jainism, creeds that promoted nonviolence, proscribed ostentation, or superfluous sacrifices and rituals, and reduced the costs of economic transactions; by coinage that increased economic accommodation in the region; and by the use of writing, which might have boosted more intricate business dealings.
1. To promote movement and trade, the Mauryans built roads, most prominently a chiefly winter-time road—the Uttarapath—which connected eastern Afghanistan to their capital Pataliputra, during the time of year when the water levels in the intersecting rivers were low, and they could be easily forded.
1. When Harsha of Kannauj, who ruled much of the Indo-Gangetic Plain from 606 to 647 CE, attempted to expand southwards, he was defeated by the Chalukya ruler of the Deccan. When his successor attempted to expand eastwards, he was defeated by the Pala king of Bengal. When the Chalukyas attempted to expand southwards, they were defeated by the Pallavas from farther south, who in turn were opposed by the Pandyas and the Cholas from still farther south.
1. Central Asian warriors became supreme during South Asia's medieval transition by deploying swift-horse cavalry skilled in firing arrows at full gallop, volley after volley.
1. The northernmost point under Indian control is the disputed Siachen Glacier in Jammu and Kashmir; however, the Government of India regards the entire region of the former princely state of Jammu and Kashmir, including Gilgit-Baltistan administered by Pakistan, to be its territory. It therefore assigns the latitude 37° 6′ to its northernmost point.
1. A biodiversity hotspot is a biogeographical region which has more than 1,500 vascular plant species, but less than 30% of its primary habitat.
1. During the last years of British rule, elections were held in 1946 in all provinces of British India. The Congress won electoral victories in eight of 11 provinces. A Congress-led government was formed in September; Jawaharlal Nehru served as interim prime minister.
1. Congress had the support of left-leaning parties and MPs who opposed the BJP.
1. The 0% results from rounding to two decimal places.
1. Caste is a form of social stratification characterised by endogamy, hereditary transmission of an occupation, ritual status in a hierarchy, and customary social interaction or exclusion defined by cultural notions of purity and pollution.
1. Ancient and medieval Indian mathematical works, all composed in Sanskrit usually consisted of two sections: *sutras* in which a set of rules or problems were stated with economy in verse, and a prose commentary that explained the problem in more detail and provided justification for the solution.
1. Apart from geometric series
1. Among young urban middle-class women, for example, a proficiency in classical dance is sometimes a sought-after social achievement.
1. The classical status increases a dance's visibility and attracts more funding from agencies and ticket purchases from audiences.
1. Given the geographical distribution of the chosen dances and their stylistic range, the choices could be seen as a facet of India's ethos of national integration.
1. As per the Madras Devadasis (Prevention of Dedication) Act after agitation from the Indian middle and upper classes.
1. The Central Asian custom of buying bread outside the home accompanied the Mughals to India.
1. Genetic studies have shown that mangos were first domesticated in the region between northeastern India, northwestern Myanmar, and Bangladesh.

## References

1. National Informatics Centre 2005.
1. "National Symbols | National Portal of India". India.gov.in. Archived from the original on 4 February 2017. Retrieved 1 March 2017. The National Anthem of India Jana Gana Mana, composed originally in Bengali by Rabindranath Tagore, was adopted in its Hindi version by the Constituent Assembly as the National Anthem of India on 24 January 1950.
1. "National anthem of India: a brief on 'Jana Gana Mana'". News18. 14 August 2012. Archived from the original on 17 April 2019. Retrieved 7 June 2019.
1. Wolpert 2003, p. 1.
1. Constituent Assembly of India 1950.
1. Ministry of Home Affairs 1960.
1. "Profile | National Portal of India". India.gov.in. Archived from the original on 30 August 2013. Retrieved 23 August 2013.
1. "Constitutional Provisions – Official Language Related Part-17 of the Constitution of India". *Department of Official Language via Government of India*. Archived from the original on 18 April 2021. Retrieved 18 April 2021.
1. "50th Report of the Commissioner for Linguistic Minorities in India (July 2012 to June 2013)" (PDF). Commissioner for Linguistic Minorities, Ministry of Minority Affairs, Government of India. Archived from the original (PDF) on 8 July 2016. Retrieved 26 December 2014.
1. Eberhard, David M.; Simons, Gary F.; Fennig, Charles D. (2025). "India". *Ethnologue: Languages of the World* (28 ed.). Archived from the original on 3 March 2025. Retrieved 10 November 2024.
1. "C −1 Population by religious community – 2011". Office of the Registrar General & Census Commissioner. Archived from the original on 25 August 2015. Retrieved 25 August 2015.
1. Library of Congress 2004.
1. "India population 2026". *Statista*. Retrieved 4 May 2026.
1. "Population Enumeration Data (Final Population)". *2011 Census Data*. Office of the Registrar General & Census Commissioner, India. Archived from the original on 22 May 2016. Retrieved 17 June 2016.
1. "A – 2 Decadal Variation in Population Since 1901" (PDF). *2011 Census Data*. Office of the Registrar General & Census Commissioner, India. Archived from the original (PDF) on 30 April 2016. Retrieved 17 June 2016.
1. "World Economic Outlook Database (April 2026 Edition)". *www.imf.org*. International Monetary Fund. 14 April 2026. Retrieved 18 April 2026.
1. "Gini index (World Bank estimate) – India". World Bank. Archived from the original on 2 September 2025. Retrieved 31 January 2022.
1. "Human Development Report 2025" (PDF). United Nations Development Programme. 6 May 2025. Archived (PDF) from the original on 6 May 2025. Retrieved 6 May 2025.
 - *The Essential Desk Reference*. Oxford University Press. 2002. p. 76. ISBN 978-0-19-512873-4. "Official name: Republic of India.";
 - John Da Graça (2017). *Heads of State and Government*. London: Macmillan. p. 421. ISBN 978-1-349-65771-1. "Official name: Republic of India; Bharat Ganarajya (Hindi)";
 - Graham Rhind (2017). *Global Sourcebook of Address Data Management: A Guide to Address Formats and Data in 194 Countries*. Taylor & Francis. p. 302. ISBN 978-1-351-93326-1. "Official name: Republic of India; Bharat.";
 - Bradnock, Robert W. (2015). *The Routledge Atlas of South Asian Affairs*. Routledge. p. 108. ISBN 978-1-317-40511-5. "Official name: English: Republic of India; Hindi:Bharat Ganarajya";
 - *Penguin Compact Atlas of the World*. Penguin. 2012. p. 140. ISBN 978-0-7566-9859-1. "Official name: Republic of India";
 - *Merriam-Webster's Geographical Dictionary* (3rd ed.). Merriam-Webster. 1997. pp. 515–516. ISBN 978-0-87779-546-9. "Officially, Republic of India";
 - *Complete Atlas of the World: The Definitive View of the Earth* (3rd ed.). DK Publishing. 2016. p. 54. ISBN 978-1-4654-5528-4. "Official name: Republic of India";
 - *Worldwide Government Directory with Intergovernmental Organizations 2013*. CQ Press. 2013. p. 726. ISBN 978-1-4522-9937-2.

1. James, K. S.; Sekher, T. V. (2024). "India's Population Change: Critical Issues and Prospects.". In James, K. S.; Sekher, T. V. (eds.). *India Population Report* (1st ed.). Cambridge: Cambridge University Press. pp. 1–18. doi:10.1017/9781009318846.003. ISBN 978-1-00-931886-0.
1. Metcalf & Metcalf 2012, p. 327: "Even though much remains to be done, especially in regard to eradicating poverty and securing effective structures of governance, India's achievements since independence in sustaining freedom and democracy have been singular among the world's new nations."
1. Stein, Burton (2012). Arnold, David (ed.). *A History of India*. The Blackwell History of the World Series (2nd ed.). Wiley-Blackwell. One of these is the idea of India as 'the world's largest democracy', but a democracy forged less by the creation of representative institutions and expanding electorate under British rule than by the endeavours of India's founding fathers – Gandhi, Nehru, Patel and Ambedkar – and the labours of the Constituent Assembly between 1946 and 1949, embodied in the Indian constitution of 1950. This democratic order, reinforced by the regular holding of nationwide elections and polling for the state assemblies, has, it can be argued, consistently underpinned a fundamentally democratic state structure – despite the anomaly of the Emergency and the apparent durability of the Gandhi-Nehru dynasty.
1. Fisher 2018, pp. 184–185: "Since 1947, India's internal disputes over its national identity, while periodically bitter and occasionally punctuated by violence, have been largely managed with remarkable and sustained commitment to national unity and democracy."
1. "Ministry of Home Affairs (Department of Border Management)" (PDF). Archived from the original (PDF) on 17 March 2015. Retrieved 1 September 2008.
1. Petraglia & Allchin 2007, p. 10: "Y-Chromosome and Mt-DNA data support the colonization of South Asia by modern humans originating in Africa. [...] Coalescence dates for most non-European populations average to between 73 and 55 ka."
1. Dyson 2018, p. 1: "Modern human beings—*Homo sapiens*—originated in Africa. Then, intermittently, sometime between 60,000 and 80,000 years ago, tiny groups of them began to enter the north-west of the Indian subcontinent. It seems likely that initially they came by way of the coast. [...] it is virtually certain that there were *Homo sapiens* in the subcontinent 55,000 years ago, even though the earliest fossils that have been found of them date to only about 30,000 years before the present."
1. Fisher 2018, p. 23: "Scholars estimate that the first successful expansion of the *Homo sapiens* range beyond Africa and across the Arabian Peninsula occurred from as early as 80,000 years ago to as late as 40,000 years ago, although there may have been prior unsuccessful emigrations. Some of their descendants extended the human range ever further in each generation, spreading into each habitable land they encountered. One human channel was along the warm and productive coastal lands of the Persian Gulf and northern Indian Ocean. Eventually, various bands entered India between 75,000 years ago and 35,000 years ago."
1. Dyson 2018, p. 28
 - Dyson 2018, pp. 4–5.
 - Fisher 2018, p. 33.

1. Lowe 2015, pp. 1–2: "It consists of 1,028 hymns (*sūktas*), highly crafted poetic compositions originally intended for recital during rituals and for the invocation of and communication with the Indo-Aryan gods. Modern scholarly opinion largely agrees that these hymns were composed between around 1500 BCE and 1200 BCE, during the eastward migration of the Indo-Aryan tribes from the mountains of what is today northern Afghanistan across the Punjab into north India."
 - Witzel 2003, pp. 68–70: "It is known from internal evidence that the Vedic texts were orally composed in northern India, at first in the Greater Punjab and later on also in more eastern areas, including northern Bihar, between ca. 1500 BCE and ca. 500–400 BCE. The oldest text, the Rgveda, must have been more or less contemporary with the Mitanni texts of northern Syria/Iraq (1450–1350 BCE); [...] The Vedic texts were orally composed and transmitted, without the use of script, in an unbroken line of transmission from teacher to student that was formalised early on. This ensured an impeccable textual transmission superior to the classical texts of other cultures; it is in fact something of a *tape-recording* of ca. 1500–500 BCE. Not just the actual words, but even the long-lost musical (tonal) accent (as in old Greek or in Japanese) has been preserved up to the present. [...] The RV text was composed before the introduction and massive use of iron, that is before ca. 1200–1000 BCE."
 - Doniger 2014, pp. xviii, 10: "A Chronology of Hinduism: ca. 1500–1000 BCE Rig Veda; ca. 1200–900 BCE Yajur Veda, Sama Veda and Atharva Veda [...] Hindu texts began with the *Rig Veda* ('Knowledge of Verses'), composed in northwest India around 1500 BCE; the first of the three Vedas, it is the earliest extant text composed in Sanskrit, the language of ancient India."
 - Ludden 2014, p. 19
 - Dyson 2018, pp. 14–15
 - Robb 2011, pp. 46–

 - Jamison & Brereton 2020, pp. 2, 4–5: "The Ṛgveda is one of the four Vedas, which together constitute the oldest texts in Sanskrit and the earliest evidence for what will become Hinduism. [...] Although Vedic religion is very different in many regards from what is known as Classical Hinduism, the seeds are there. Gods like Viṣṇu and Śiva (under the name Rudra), who will become so dominant later, are already present in the Ṛgveda, though in roles both lesser than and different from those they will later play, and the principal Ṛgvedic gods like Indra remain in later Hinduism, though in diminished capacity."
 - Flood 2020, p. 4, see note 4: "I take the term 'Hinduism' to meaningfully denote a range and history of practice characterised by a number of features, particularly reference to Vedic textual and sacrificial origins, belonging to endogamous social units (*jāti*/*varṇa*), participating in practices that involve making an offering to a deity and receiving a blessing (*pūjā*), and a first-level cultural polytheism (although many Hindus adhere to a second-level monotheism in which many gods are regarded as emanations or manifestations of the one, supreme being)."
 - Michaels 2017, p. 86: "Almost all traditional Hindu families observe until today at least three *samskaras* (initiation, marriage, and death ritual). Most other rituals have lost their popularity, are combined with other rites of passage, or are drastically shortened. Although *samskaras* vary from region to region, from class (*varna*) to class, and from caste to caste, their core elements remain the same owing to the common source, the Veda, and a common priestly tradition preserved by the *Brahmin* priests."
 - Flood 1996, p. 35: "It is this Sanskrit, vedic, tradition which has maintained a continuity into modern times and which has provided the most important resource and inspiration for Hindu traditions and individuals. The Veda is the foundation for most later developments in what is known as Hinduism."

1. Dyson 2018, pp. 16, 25.
1. Dyson 2018, p. 16
1. Fisher 2018, p. 59.
 - Dyson 2018, pp. 16–17.
 - Fisher 2018, p. 67.
 - Robb 2011, pp. 56–57
 - Ludden 2014, pp. 29–30.

 - Ludden 2014, pp. 28–29.
 - Glenn Van Brummelen (2014). "Arithmetic". In Thomas F. Glick; Steven Livesey; Faith Wallis (eds.). *Medieval Science, Technology, and Medicine: An Encyclopedia*. Routledge. pp. 46–48. ISBN 978-1-135-45932-1.

 - Dyson 2018, p. 20.
 - Stein 2010, p. 90.
 - Ramusack, Barbara N. (1999). "Women in South Asia". In Barbara N. Ramusack; Sharon L. Sievers (eds.). *Women in Asia: Restoring Women to History*. Indiana University Press. pp. 27–29. ISBN 978-0-253-21267-2.

1. Kulke & Rothermund 2016, pp. 122–123.
1. Asher & Talbot 2006, p. 17.
 - Ludden 2014, p. 54.
 - Asher & Talbot 2006, pp. 78–79.
 - Fisher 2018, p. 76.

 - Ludden 2014, pp. 68–70.
 - Asher & Talbot 2006, pp. 19, 24.

 - Dyson 2018, p. 48.
 - Asher & Talbot 2006, p. 52.

1. Asher & Talbot 2006, p. 74.
1. Asher & Talbot 2006, p. 267.
1. Asher & Talbot 2006, p. 152.
1. Fisher 2018, p. 106.
1. Asher 1992, p. 250.
 - Asher & Talbot 2006, p. 289.
 - Fisher 2018, p. 120.

1. Taylor, Miles (2016). "The British royal family and the colonial empire from the Georgians to Prince George". In Aldrish, Robert; McCreery, Cindy (eds.). *Crowns and Colonies: European Monarchies and Overseas Empires*. Manchester University Press. pp. 38–39. ISBN 978-1-5261-0088-7.
1. Peers 2013, p. 76.
1. Embree, Ainslie Thomas; Hay, Stephen N.; Bary, William Theodore De (1988). "Nationalism Takes Root: The Moderates". *Sources of Indian Tradition: Modern India and Pakistan*. Columbia University Press. p. 85. ISBN 978-0-231-06414-9.
1. Marshall, P. J. (2001). *The Cambridge Illustrated History of the British Empire*. Cambridge University Press. p. 179. ISBN 978-0-521-00254-7. The first modern nationalist movement to arise in the non-European empire, and one that became an inspiration for many others, was the Indian Congress.
1. Chiriyankandath, James (2016). *Parties and Political Change in South Asia*. Routledge. p. 2. ISBN 978-1-317-58620-3. South Asian parties include several of the oldest in the post-colonial world, foremost among them the 129-year-old Indian National Congress that led India to independence in 1947
1. Metcalf & Metcalf 2012, p. 202: "The year 1919 was a watershed in the modern history of India. [...] By its end the Montagu–Chelmsford reforms... were enacted. [...] The year, however, also brought the repressive Rowlatt bills and the catastrophe of the Amritsar massacre. For many, if not most, Indians the reforms had become a poisoned chalice. They chose instead a novel course of political action, that of 'non-violent non-cooperation', and a new leader, Mohandas K. Gandhi, only recently returned from twenty years in South Africa. Gandhi would endure as a lasting symbol of moral leadership for the entire world community."
1. Stein 2010, p. 289: "Gandhi was the leading genius of the later and ultimately successful campaign for India's independence"
 - Copland 2001, pp. 71–78.
 - Metcalf & Metcalf 2006, p. 222.

1. Dyson 2018, pp. 219, 262.
1. Fisher 2018, p. 8.
1. Metcalf & Metcalf 2012, pp. 265–266.
1. Dyson 2018, p. 216.
 - "Kashmir, region Indian subcontinent". *Encyclopaedia Britannica*. Archived from the original on 13 August 2019. Retrieved 15 August 2019. Kashmir, region of the northwestern Indian subcontinent ... has been the subject of dispute between India and Pakistan since the partition of the Indian subcontinent in 1947.
 - Pletcher, Kenneth. "Aksai Chin, Plateau Region, Asia". *Encyclopaedia Britannica*. Archived from the original on 2 April 2019. Retrieved 16 August 2019. Aksai Chin, Chinese (Pinyin) Aksayqin, portion of the Kashmir region,... constitutes nearly all the territory of the Chinese-administered sector of Kashmir that is claimed by India
 - Bosworth, C. E (2006). "Kashmir". *Encyclopedia Americana: Jefferson to Latin*. Scholastic Library Publishing. p. 328. ISBN 978-0-7172-0139-6. KASHMIR, kash'mer, the northernmost region of the Indian subcontinent, administered partly by India, partly by Pakistan, and partly by China. The region has been the subject of a bitter dispute between India and Pakistan since they became independent in 1947

1. Narayan, Jitendra; John, Denny; Ramadas, Nirupama (2018). "Malnutrition in India: status and government initiatives". *Journal of Public Health Policy*. **40** (1): 126–141. doi:10.1057/s41271-018-0149-5. PMID 30353132.
1. Balakrishnan, Kalpana; Dey, Sagnik; et al. (2019). "The impact of air pollution on deaths, disease burden, and life expectancy across the states of India: the Global Burden of Disease Study 2017". *The Lancet Planetary Health*. **3** (1): e26–e39. doi:10.1016/S2542-5196(18)30261-4. PMC 6358127. PMID 30528905.
1. Karanth & Gopal 2005, p. 374.
1. "India (n)". *Oxford English Dictionary* (online ed.). Oxford University Press. doi:10.1093/OED/3183874375. (Subscription or participating institution membership required.)
1. Kuiper 2010, p. 86.
1. Clémentin-Ojha 2014.
1. *The Constitution of India* (PDF). Ministry of Law and Justice. 1 December 2007. Archived from the original (PDF) on 9 September 2014. Retrieved 3 March 2012. Article 1(1): India, that is Bharat, shall be a Union of States.
1. Jha, Dwijendra Narayan (2014). *Rethinking Hindu Identity*. Routledge. p. 11. ISBN 978-1-317-49034-0.
1. Singh 2017, p. 253.
1. Barrow 2003.
1. Paturi, Joseph; Patterson, Roger (2016). "Hinduism (with Hare Krishna)". In Hodge, Bodie; Patterson, Roger (eds.). *World Religions & Cults Volume 2: Moralistic, Mythical and Mysticism Religions*. United States: New Leaf Publishing Group. pp. 59–60. ISBN 978-0-89051-922-6. The actual term Hindu first occurs as a Persian geographical term for the people who lived beyond the Indus River. The term Hindu originated as a geographical term and did not refer to a religion. Later, Hindu was taken by European languages from the Arabic term al-Hind, which referred to the people who lived across the Indus River. This Arabic term was itself taken from the Persian term Hindū, which refers to all Indians. By the 13th century, Hindustan emerged as a popular alternative name for India, meaning the "land of Hindus."
1. "Hindustan". *Encyclopædia Britannica*. Archived from the original on 17 July 2011. Retrieved 17 July 2011.
1. Lowe, John J. (2017). *Transitive Nouns and Adjectives: Evidence from Early Indo-Aryan*. Oxford University Press. p. 58. ISBN 978-0-19-879357-1. The term 'Epic Sanskrit' refers to the language of the two great Sanskrit epics, the Mahābhārata and the Rāmāyaṇa.... It is likely, therefore, that the epic-like elements found in Vedic sources and the two epics that we have are not directly related, but that both drew on the same source, an oral tradition of storytelling that existed before, throughout, and after the Vedic period.
1. Mattern 2019, pp. 146–147 All non-African human populations share a common ancestry in the recent past, about 80,000 to 50,000 years ago. Some time within this period, a group of modern humans migrated from Africa, traversed southern Asia, and crossed the sea to the ancient continent of Sahul (now Australia, Tasmania, and Papua New Guinea), picking up Neanderthal and Denisovan genes along the way; branches reached Europe somewhat later, and Americas last. This was not the first migration of anatomically modern humans out of Africa.... But for the most part, earlier populations of humans around Eurasia sputtered out, returned to Africa, or were replaced by humans from the last migration out of Africa.}}
1. Wright 2010, pp. 45–51.
1. Wright 2010, p. 107.
1. Wright 2010, pp. 145–146.
1. Dyson 2018, pp. 16, 25.
1. Evans, Nicholas (2009). *Dying Words: Endangered languages and what they have to tell us*. John Wiley & Sons. pp. 27–. ISBN 978-0-631-23305-3.
1. Lowe, John J. (2017). *Transitive Nouns and Adjectives: Evidence from Early Indo-Aryan*. Oxford University Press. p. 58. ISBN 978-0-19-879357-1. The term 'Epic Sanskrit' refers to the language of the two great Sanskrit epics, the Mahābhārata and the Rāmāyaṇa.... It is likely, therefore, that the epic-like elements found in Vedic sources and the two epics that we have are not directly related, but that both drew on the same source, an oral tradition of storytelling that existed before, throughout, and after the Vedic period.
1. Stein 2010, pp. 21, 61–62.
1. Dyson 2018, pp. 16–17.
1. Roy 2012, p. 28.
1. Iori 2023, pp. 184, 219.
1. Ludden 2014, pp. 28–29.
1. Dyson 2018, p. 19.
1. Stein 2010, p. 73.
1. Elverskog, Johan (2020). *The Buddha's Footprint: An Environmental History of Asia*. Philadelphia: University of Pennsylvania Press. p. 56. ISBN 978-0-8122-5183-8. The imperial edicts of Asoka echo this commodity view of trees. In Pillar Edict V, Asoka decreed that "forests must not be burned without reason." The Buddhist community took this mandate further by declaring that in order to protect forests from such conflagrations monks were allowed to set counterfires
1. Fisher 2018, p. 72.
1. Kulke & Rothermund 2016, pp. 118, 126.
1. Robb 2011, pp. 68–69.
1. Stein 2010, pp. 93–94.
1. Gilbert 2017, pp. 54–55.
1. Stein 2010, p. 98.
1. Stein 2010, pp. 100–101.
1. Stein 2010, p. 99.
1. Stein 2010, p. 116.
1. Stein 2010, pp. 115–116.
1. Stein 2010, pp. 116–117.
1. Stein 2010, p. 118.
1. Stein 2010, pp. 118–119.
1. Stein 2010, pp. 121–123.
1. Ludden 2014, p. 87.
1. Ludden 2014, p. 85.
1. Asher & Talbot 2022, p. 54.
1. Metcalf & Metcalf 2012, p. 41.
1. Asher & Talbot 2008, pp. 50–51.
1. Asher & Talbot 2008, p. 53.
1. Metcalf & Metcalf 2012, p. 47.
1. Robb 2011, p. 97–98.
1. Stein 2010, p. 159.
1. Asher & Talbot 2022, p. 136.
1. Robb 2011, pp. 108–109.
1. Metcalf & Metcalf 2012, p. 15.
1. Asher & Talbot 2022, pp. 136, 151–152.
1. Metcalf & Metcalf 2012, p. 17.
1. Asher & Talbot 2008, p. 158.
1. Stein 2010, pp. 164.
1. Asher & Talbot 2022, p. 187.
1. Asher & Talbot 2008, p. 186.
1. Metcalf & Metcalf 2006, pp. 23–24.
1. Asher & Talbot 2008, p. 256.
1. Asher & Talbot 2008, p. 286.
1. Metcalf & Metcalf 2006, pp. 44–49.
1. Robb 2011, pp. 115–117.
1. Ludden 2002, pp. 128–132.
1. Metcalf & Metcalf 2006, pp. 51–55.
1. Metcalf & Metcalf 2006, pp. 68–71.
1. Asher & Talbot 2008, p. 289.
1. Robb 2011, pp. 169–171.
1. Metcalf & Metcalf 2006, pp. 94–99.
1. Brown 1994, p. 83.
1. Peers 2006, p. 50.
1. Metcalf & Metcalf 2006, pp. 100–103.
1. Brown 1994, pp. 85–86.
1. Stein 2010, p. 227.
1. Metcalf & Metcalf 2006, pp. 103–108.
1. Robb 2001, p. 183.
1. Sarkar 1983, pp. 1–4.
1. Copland 2001, pp. ix–x.
1. Metcalf & Metcalf 2006, p. 123.
1. Stein 2010, p. 249.
1. Stein 2010, p. 245: An expansion of state functions in British and in princely India occurred as a result of the terrible famines of the later nineteenth century,... A reluctant regime decided that state resources had to be deployed and that anti-famine measures were best managed through technical experts.
1. Stein 2010, pp. 247–248.
1. Metcalf & Metcalf 2006, p. 126.
1. Metcalf & Metcalf 2006, p. 97.
1. Metcalf & Metcalf 2006, p. 163.
1. Metcalf & Metcalf 2006, p. 167.
1. Metcalf & Metcalf 2006, pp. 195–197.
1. Metcalf & Metcalf 2006, p. 203.
1. Metcalf & Metcalf 2006, p. 231.
1. Javalgi, Rajshekhar (Raj) G.; Grossman, David A. (2016). "7 Understanding the Characteristics and Entrepreneurial Activities of Middle-Class Consumers in Emerging Markets: The Case of India". In Marsh, Leslie L.; Li, Hongmei (eds.). *The Middle Class in Emerging Societies: Consumers, Lifestyles and Markets*. Routledge Research in Cultural and Media Studies Series. Routledge. doi:10.4324/978135717692-10 (inactive 8 December 2025). ISBN 978-1-138-85882-4. Between now and 2039, India is projected to add over 1 billion people to the global middle class creating the world's fifth-largest consumer market (Dobbs).... India's middle class saw its largest growth during the early 1990s when economic reforms led to integration into global markets. As Western countries were experiencing economic contraction, India's economy continued to grow above 5 percent.{{cite book}}: CS1 maint: DOI inactive as of December 2025 (link)
1. Metcalf & Metcalf 2006, pp. 265–266.
1. Metcalf & Metcalf 2006, pp. 266–270.
1. Metcalf & Metcalf 2006, p. 253.
1. Metcalf & Metcalf 2006, p. 274.
1. Metcalf & Metcalf 2006, pp. 247–248.
1. Ali & Aitchison 2005.
1. Molnar 2015, p. 117.
1. Molnar 2015, p. 118.
1. Molnar 2015, p. 128.
1. Dikshit & Schwartzberg 2023, p. 7.
1. Prakash et al. 2000.
1. Kaul 1970, p. 160, " The Aravalli range boldy defines the eastern limit of the arid and semi-arid zone. Probably the more humid conditions that prevail near the Aravallis prevented the extension of aridity towards the east and the Ganges Valley. It is noteworthy that, wherever there are gaps in this range, sand has advanced to the east of it."
1. Prasad 1974, p. 372, " The topography of the Indian Desert is dominated by the Aravalli Ranges on its eastern border, which consist largely of tightly folded and highly metamorphosed Archaean rocks."
1. Fisher 2018, p. 83, " East of the lower Indus lay the inhospitable Rann of Kutch and Thar Desert. East of the upper Indus lay the more promising but narrow corridor between the Himalayan foothills on the north and the Thar Desert and Aravalli Mountains on the south. At the strategic choke point, just before reaching the fertile, well-watered Gangetic plain, sat Delhi. On this site, where life giving streams running off the most northern spur of the rocky Aravalli ridge flowed into the Jumna river, and where the war-horse and war-elephant trade intersected, a series of dynasties built fortified capitals."
1. Dikshit & Schwartzberg 2023, p. 8.
1. Dikshit & Schwartzberg 2023, pp. 9–10.
1. Ministry of Information and Broadcasting 2007, p. 1.
1. Dikshit & Schwartzberg 2023, p. 15.
1. Duff 1993, p. 353.
1. Basu & Xavier 2017, p. 78.
1. Dikshit & Schwartzberg 2023, p. 16.
1. Dikshit & Schwartzberg 2023, p. 17.
1. Kumar et al. 2006.
1. Dikshit & Schwartzberg 2023, p. 12.
1. Dikshit & Schwartzberg 2023, p. 13.
1. Mcgrail et al. 2003, p. 257.
1. Chang 1967, pp. 391–394.
1. Posey 1994, p. 118.
1. Wolpert 2003, p. 4.
1. Heitzman & Worden 1996, p. 97.
1. Sharma, Vibha (15 June 2020). "Average temperature over India projected to rise by 4.4 degrees Celsius: Govt report on impact of climate change in country". *The Tribune*. Archived from the original on 21 September 2020. Retrieved 30 November 2020.
1. Sethi, Nitin (3 February 2007). "Global warming: Mumbai to face the heat". *The Times of India*. Archived from the original on 23 October 2012. Retrieved 11 March 2021.
1. Gupta, Vivek; Jain, Manoj Kumar (2018). "Investigation of multi-model spatiotemporal mesoscale drought projections over India under climate change scenario". *Journal of Hydrology*. **567**: 489–509. Bibcode:2018JHyd..567..489G. doi:10.1016/j.jhydrol.2018.10.012.
1. *Megadiverse Countries*. Biodiversity A–Z, UN Environment World Conservation Monitoring Centre. Archived from the original on 3 September 2014. Retrieved 17 October 2021.
1. "Animal Discoveries 2011: New Species and New Records" (PDF). Zoological Survey of India. 2012. Archived from the original (PDF) on 16 January 2013. Retrieved 20 July 2012.
1. Puri, S. K. "Biodiversity Profile of India". *ces.iisc.ernet.in*. Archived from the original on 21 November 2011. Retrieved 20 June 2007.
1. Basak 1983, p. 24.
1. *India*. International Union for Conservation of Nature (IUCN). 2019. Archived from the original on 1 November 2020. Retrieved 21 May 2019.
1. Venkataraman, Krishnamoorthy; Sivaperuman, Chandrakasan (2018). "Biodiversity Hotspots in India". In Sivaperuman, Chandrakasan; Venkataraman, Krishnamoorthy (eds.). *Indian Hotspots: Vertebrate Faunal Diversity, Conservation and Management*. Springer. p. 5. ISBN 978-981-10-6605-4.
1. Jha, Raghbendra (2018). *Facets of India's Economy and Her Society Volume II: Current State and Future Prospects*. Springer. p. 198. ISBN 978-1-349-95342-4.
1. "Forest Cover in States/UTs in India in 2019". Forest Research Institute via National Informatics Centre. Archived from the original on 19 October 2021. Retrieved 16 October 2021.
1. Tritsch 2001, pp. 11–12.
1. Tritsch 2001, p. 12: "India has two natural zones of thorn forest, one in the rain shadow area of the Deccan Plateau east of the Western Ghats, and the other in the western part of the Indo-Gangetic plain. Growth is limited only by moisture availability in these areas, so with irrigation the fertile alluvial soil of Punjab and Haryana has been turned into India's prime agricultural area. Much of the thorn forest covering the plains probably had savannah-like features now no longer visible."
1. Goyal, Anupam (2006). *The WTO and International Environmental Law: Towards Conciliation*. Oxford University Press. p. 295. ISBN 978-0-19-567710-2. Quote: "The Indian government successfully argued that the medicinal *neem* tree is part of traditional Indian knowledge. (page 295)"
1. Hughes, Julie E. (2013). *Animal Kingdoms*. Harvard University Press. p. 106. ISBN 978-0-674-07480-4. At same time, the leafy pipal trees and comparative abundance that marked the Mewari landscape fostered refinements unattainable in other lands.
1. Ameri, Marta (2018). "Letting the Pictures Speak: An Image-Based Approach to the Mythological and Narrative Imagery of the Harappan World". In Ameri, Marta; Costello, Sarah Kielt; Jamison, Gregg; Scott, Sarah Jarmer (eds.). *Seals and Sealing in the Ancient World: Case Studies from the Near East, Egypt, the Aegean, and South Asia*. Cambridge University Press. pp. 156–157. ISBN 978-1-108-17351-3. Quote: "The last of the centaurs has the long, wavy, horizontal horns of a markhor, a human face, a heavy-set body that appears bovine, and a goat tail... This figure is often depicted by itself, but it is also consistently represented in scenes that seem to reflect the adoration of a figure in a pipal tree or arbour and which may be termed ritual. These include fully detailed scenes like that visible in the large 'divine adoration' seal from Mohenjo-daro."
1. Paul Gwynne (2011). *World Religions in Practice: A Comparative Introduction*. John Wiley & Sons. p. 358. ISBN 978-1-4443-6005-9. The tree under which Sakyamuni became the Buddha is a peepal tree (*Ficus religiosa*).
1. Crame & Owen 2002, p. 142.
1. Karanth 2006.
1. Tritsch 2001, p. 14.
1. Singh, M.; Kumar, A.; Molur, S. (2008). "*Semnopithecus johnii*". *IUCN Red List of Threatened Species*. **2008** e.T44694A10927987. doi:10.2305/IUCN.UK.2008.RLTS.T44694A10927987.en. Retrieved 26 April 2025.
1. Fischer, Johann. "Semnopithecus johnii". ITIS. Archived from the original on 29 August 2018. Retrieved 27 August 2018.
1. Biju, S.D.; Dutta, S.; Ravichandran, M.S.; Vasudevan, K.; Vijayakumar, S.P.; Srinivasulu, C.; Dasaramji Buddhe, G. (2016) [errata version of 2004 assessment]. "*Duttaphrynus beddomii*". *IUCN Red List of Threatened Species*. **2004** e.T54584A86543952. doi:10.2305/IUCN.UK.2004.RLTS.T54584A11155448.en. Retrieved 26 April 2025.
1. Frost, Darrel R. (2015). "*Duttaphrynus beddomii* (Günther, 1876)". *Amphibian Species of the World: an Online Reference. Version 6.0*. American Museum of Natural History. Archived from the original on 21 July 2015. Retrieved 13 September 2015.
1. IUCN 1994, p. xli.
1. Lovette, Irby J.; Fitzpatrick, John W. (2016). *Handbook of Bird Biology*. John Wiley & Sons. p. 599. ISBN 978-1-118-29105-4.
1. Tritsch 2001, p. 15: "Before it was so heavily settled and intensively exploited, the Punjab was dominated by thorn forest interspersed by rolling grasslands which were grazed on by millions of Blackbuck, accompanied by their dominant predator, the Cheetah. Always keen hunters, the Moghul princes kept tame cheetahs which were used to chase and bring down the Blackbuck. Today the Cheetah is extinct in India and the severely endangered Blackbuck no longer exists in the Punjab."
1. Ministry of Environment and Forests 1972.
1. Department of Environment and Forests 1988.
1. "Biosphere" (PDF). Archived (PDF) from the original on 26 March 2023. Retrieved 28 June 2023.
1. "Annotated List of Wetlands of International Importance | India" (PDF). *rsis.ramsar.org*. Ramsar Sites Information Service. Archived (PDF) from the original on 3 July 2025. Retrieved 16 April 2025.
1. *Reviving the Roar: India's Tiger Population Is On the Rise*. 13 April 2023. Archived from the original on 15 April 2023. Retrieved 15 April 2023.
1. Burnell & Calvert 1999, p. 125.
1. Election Commission of India.
1. Sáez, Lawrence; Sinha, Aseema (2010). "Political cycles, political institutions and public expenditure in India, 1980–2000". *British Journal of Political Science*. **40** (1): 91–113. doi:10.1017/s0007123409990226.
1. Judd 2004, pp. 170–71
1. Judd 2004, p. 172
1. Sarvepalli Gopal (1976). *Jawaharlal Nehru: A Biography*. Harvard University Press. p. 362. ISBN 978-0-674-47310-2. Retrieved 21 February 2012.
1. Bhambhri 1992, pp. 118, 143.
1. "Narasimha Rao Passes Away". *The Hindu*. 24 December 2004. Archived from the original on 13 February 2009. Retrieved 2 November 2008.
1. Dunleavy, Diwakar & Dunleavy 2007.
1. Kulke & Rothermund 2004, p. 384.
1. Business Standard 2009.
1. "BJP first party since 1984 to win parliamentary majority on its own". *DNA*. Indo-Asian News Service. 16 May 2014. Archived from the original on 21 May 2014. Retrieved 20 May 2014.
1. Mashal, Mujib (4 June 2024). "Modi Wins 3rd Term in India Election With Closer Results Than Expected". *The New York Times*.
1. "Democracy Report 2026, Unraveling The Democratic Era?, V-Dem Institute" (PDF). Retrieved 17 March 2026.
1. Spear 1990, p. 242.
1. Spear 1990, p. 243.
1. Sharma 1950.
1. Sharma 2007, p. 162.
1. Sharma 2007, p. 31.
1. Mathew 2003, p. 524.
1. Neuborne 2003, p. 478.
1. Sharma 2007, pp. 238, 255.
1. Sripati 1998, pp. 423–424.
1. Pylee 2003b, p. 314.
1. Sharma 2007, p. 49.
1. "India". *Commonwealth Local Government Forum*. Archived from the original on 15 July 2019. Retrieved 7 September 2019.
1. Dinkel, Jürgen (2018). *The Non-Aligned Movement: Genesis, Organization and Politics (1927–1992)*. Brill. pp. 92–93. ISBN 978-90-04-33613-1.
1. Storm, Eric (2024). *Nationalism: A World History*. Princeton University Press. ISBN 978-0-691-23309-3. LCCN 2024015293. Archived from the original on 20 March 2025. Retrieved 18 March 2025. The whole constellation changed when India and Pakistan gained independence as dominions, which was a solution that made possible a speedier withdrawal of the British. In the end, India decided to become a republic, although the leadership preferred to remain within the Commonwealth.
1. "The London Declaration". Commonwealth of Nations. 26 April 1949. Archived from the original on 6 July 2010. Retrieved 4 July 2013.
1. Rothermund 2000, pp. 48, 227.
1. (a) Guyot-Rechard, Berenice (2017). *Shadow States: India, China and the Himalayas, 1910–1962*. Cambridge University Press. p. 235. ISBN 978-1-107-17679-9. By invading NEFA, the PRC did not just aim to force a humiliated India to recognise its possession of the Aksai Chin. It also hoped to get, once and for all, the upper hand in their shadowing competition. (b) Chubb, Andrew (2021). "The Sino-Indian Border Crisis: Chinese Perceptions of Indian Nationalism". In Golley, Jane; Jaivan, Linda; Strange, Sharon (eds.). *Crisis*. Australian National University Press. pp. 231–232. ISBN 978-1-76046-439-4. The ensuing cycle of escalation culminated in the 1962 Sino-Indian border war in which Mao Zedong's troops overran almost the entire state of Arunachal Pradesh in the eastern sector before unilaterally withdrawing, as if to underline the insult; most of the war's several thousand casualties were Indian. The PLA's decisive victories in the 1962 war not only humiliated the Indian Army, they also entrenched a status quo in Ladakh that was highly unfavourable for India, in which China controls almost all of the disputed territory. A nationalistic press and commentariat have kept 1962 vivid in India's popular consciousness. (c) Lintner, Bertil (2018). *China's India War: Collision Course on the Roof of the World*. Oxford University Press. ISBN 978-0-19-909163-8. Lin Biao was put in charge of the operation and that alliance between Mao and his loyal de facto chief of the PLA made the attack on India possible. With China's ultimate victory in the war, Mao's ultra-leftist line had won in China; whatever critical voices that were left in the Party after all the purges fell silent. (d) Medcalf, Rory (2020). *Indo-Pacific Empire: China, America and the contest for the world's pivotal*. Manchester University Press. ISBN 978-1-5261-5077-6. From an Indian perspective, the China-India war of 1962 was a shocking betrayal of the principles of co-operation and coexistence: a surprise attack that humiliated India and personally broke Nehru. (e) Ganguly, Sumit (1997). *The Crisis in Kashmir: Portents of War, Hope of Peace*. Woodrow Wilson Center Press and Cambridge University Press. p. 44. ISBN 978-0-521-65566-8. In October 1962 India suffered the most humiliating military debacle in its post-independence history, at the hands of the Chinese People's Liberation Army (PLA). The outcome of this conflict had far-reaching consequences for Indian foreign and defence policies. The harsh defeat that the Chinese PLA had inflicted on the Indian Army called into question some of the most deeply held precepts of Nehru's foreign and defence policies. (f) Raghavan, Srinath (2019). "A Missed Opportunity? The Nehru-Zhou Enlai Summit of 1960". In Bhagavan, Manu (ed.). *India and the Cold War*. University of North Carolina Press. p. 121. ISBN 978-1-4696-5117-0. The 'forward policy' adopted by India to prevent the Chinese from occupying territory claimed by them was undertaken in the mistaken belief that Beijing would be cautious in dealing with India owing to Moscow's stance on the dispute and its growing proximity to India. These misjudgments would eventually culminate in India's humiliating defeat in the war of October–November 1962.
1. Brahma Chellaney (2006). *Asian Juggernaut: The Rise of China, India, and Japan*. HarperCollins. p. 195. ISBN 978-81-7223-650-2. Indeed, Beijing's acknowledgement of Indian control over Sikkim seems limited to the purpose of facilitating trade through the vertiginous Nathu-la Pass, the scene of bloody artillery duels in September 1967 when Indian troops beat back attacking Chinese forces.
1. Gilbert 2002, pp. 486–487.
1. Sharma 1999, p. 56.
1. Perkovich 2001, pp. 60–86, 106–125.
1. Kumar 2010.
1. Nair 2007.
1. Pandit 2009.
1. European Union 2008.
1. British Broadcasting Corporation 2009.
1. Rediff 2008 a.
1. Reuters 2010.
1. Curry 2010.
1. "India Datasets". *International Monetary Fund*. Retrieved 15 April 2026.
1. Sawhney, Anoushka (14 April 2026). "IMF raises India's growth forecast to 6.5% for FY27". *The Economic Times*. ISSN 0013-0389. Retrieved 15 April 2026.
1. Nayak, Goldar & Agrawal 2010, p. xxv.
1. International Monetary Fund 2011, p. 2.
1. Kochhar, Rakesh (18 March 2021). "In the pandemic, India's middle class shrinks and poverty spreads while China sees smaller changes". *Pew Research Center*. Archived from the original on 5 December 2023. Retrieved 22 October 2024.
1. Wolpert 2003, p. xiv.
1. Organisation for Economic Co-operation and Development 2007.
1. Gargan 1992.
1. Alamgir 2008, pp. 23, 97.
1. World Trade Organization 1995.
1. Central Intelligence Agency.
1. "Remittances to India set to hit record $100bn this year, 25% higher than FDI flows". *The times of India*. 1 December 2022. Archived from the original on 3 December 2022. Retrieved 5 December 2022.
1. "India received $87 billion in remittances in 2021: World Bank". *Business Standard*. 19 November 2021. Archived from the original on 3 February 2022. Retrieved 3 February 2022.
1. "Exporters Get Wider Market Reach". *The Times of India*. 28 August 2009. Archived from the original on 12 September 2014. Retrieved 23 July 2011.
1. "Trade Map: Trade statistics for international business development". *International Trade Centre*. 1999–2019. Archived from the original on 29 September 2022. Retrieved 30 September 2022.
1. Economist 2011.
1. Economic Times 2014.
1. Bonner 2010.
1. Farrell & Beinhocker 2007.
1. "Households and NPISHs Final consumption expenditure (current US$)". *World Bank Open Data*. Archived from the original on 11 November 2020. Retrieved 20 November 2023.
1. "Employment in agriculture (% of total employment) (modeled ILO estimate)". *The World Bank*. 2019. Archived from the original on 22 August 2019. Retrieved 26 March 2022.
1. "Employment in agriculture, female (% of female employment) (modeled ILO estimate)". *The World Bank*. 2019. Archived from the original on 22 August 2019. Retrieved 26 March 2022.
1. Kapoor, Rana (27 October 2015). "Growth in organised dairy sector, a boost for rural livelihood". *Business Line*. Archived from the original on 20 July 2019. Retrieved 26 August 2019. Nearly 80 per cent of India's milk production is contributed by small and marginal farmers, with an average herd size of one to two milching animals.
1. Business Line 2010.
1. Express India 2009.
1. "India beats Japan to become world's third-largest vehicle market". *The Times of India*. 10 January 2023. Archived from the original on 25 July 2023. Retrieved 7 June 2023.
1. Nasscom 2011–2012.
1. "Indian Pharma: a strategic sector from 'Make in India' to 'Make and Develop in India'". *The Financial Express*. 16 September 2021. Archived from the original on 18 October 2021. Retrieved 18 October 2021.
1. "Indian Pharmaceutical Industry". *India Brand Equity Foundation*. 12 October 2021. Archived from the original on 11 April 2020. Retrieved 18 October 2021.
1. Biotechnology and Pharmaceutical Sector in India: sector briefing by the UK Trade and Investment 2011, utki.gov.uk
1. Yep 2011.
1. "Biotechnology in India – 2013 "biospectrum-able" Survey". Differding.com. 24 June 2013. Archived from the original on 23 February 2014. Retrieved 4 April 2014.
1. "India's Total Power Generation Capacity Crosses 300 GW Mark". NDTV. 1 August 2016. Archived from the original on 16 June 2017. Retrieved 17 October 2021.
1. Rowlatt, Justin (12 May 2020). "India's carbon emissions fall for first time in four decades". BBC News. Archived from the original on 25 January 2021. Retrieved 3 December 2020.
1. USAID (September 2018). "Greenhouse Gas Emissions in India" (PDF). Archived from the original (PDF) on 14 February 2020. Retrieved 10 June 2021.
1. UN Environment Programme (2019). "Emissions Gap Report 2019". *UNEP – UN Environment Programme*. Archived from the original on 21 April 2020. Retrieved 10 June 2021.
1. "India 2020 – Analysis". International Energy Agency. 9 January 2020. Archived from the original on 16 March 2021. Retrieved 3 December 2020.
1. Scott, Allen J.; Garofoli, Gioacchino (2007). *Development on the Ground: Clusters, Networks and Regions in Emerging Economies*. Routledge. p. 208. ISBN 978-1-135-98422-9.
1. "India's Blue Economy net getting bigger". Financial Express. 14 February 2020. Retrieved 18 July 2020.
1. "Page 279 - economic_survey_2021-2022". *www.indiabudget.gov.in*. Archived from the original on 26 February 2025. Retrieved 18 July 2022.
1. "World Population Prospects". *Population Division – United Nations*. Archived from the original on 5 February 2019. Retrieved 2 July 2023.
1. Provisional Population Totals Paper 1 of 2011 India, p. 160.
1. Rorabacher 2010, pp. 35–39.
1. Provisional Population Totals Paper 1 of 2011 India, p. 165.
1. "Population Of India (1951–2001)" (PDF). *Census of India*. Ministry of Finance. Archived from the original (PDF) on 12 August 2011. Retrieved 13 February 2013.
1. Rosling. "Gapminder". Archived from the original on 4 September 2018. Retrieved 5 September 2018.
1. "Life expectancy at birth: World, India". Our World in Data. Archived from the original on 12 November 2025. Retrieved 7 September 2025.
1. Kapoor, Mudit; Shamika, Ravi (10 February 2014). "India's missing women". *The Hindu*. Archived from the original on 9 March 2021. Retrieved 17 November 2019. In the last 50 years of Indian democracy, the absolute number of missing women has increased fourfold from 15 million to 68 million. This is not merely a reflection of the overall population growth, but rather a worsening of the dangerous trend over time. As a percentage of the female electorate, missing women have gone up significantly — from 13 per cent to approximately 20 per cent
1. "More than 63 million women 'missing' in India, statistics show". *Associated Press via The Guardian*. 30 January 2018. Archived from the original on 9 March 2021. Retrieved 17 November 2019. Quote: "More than 63 million women are "missing" statistically across India, and more than 21 million girls are unwanted by their families, government officials say. The skewed ratio of men to women is largely the result of sex-selective abortions, and better nutrition and medical care for boys, according to the government's annual economic survey, which was released on Monday. In addition, the survey found that "families where a son is born are more likely to stop having children than families where a girl is born".
1. Trivedi, Ira (15 August 2019). "A Generation of Girls Is Missing in India – Sex-selective abortion fuels a cycle of patriarchy and abuse". *Foreign Policy*. Archived from the original on 9 March 2021. Retrieved 17 November 2019. Quote: "Although it has been illegal nationwide for doctors to disclose the sex of a fetus since the 1994 Pre-Conception and Pre-Natal Diagnostic Techniques Act, the ease of ordering cheap and portable ultrasound machines, especially online, has kept the practice of sex-selective abortions alive."
1. Garg 2005.
1. Dyson & Visaria 2005, pp. 115–129.
1. Ratna 2007, pp. 271–272.
1. Chandramouli 2011.
1. "Urban Agglomerations/Cities having population 1 lakh and above" (PDF). Office of the Registrar General & Census Commissioner, India. Archived from the original (PDF) on 17 October 2013. Retrieved 12 May 2014.
1. Jolad, Shivakumar; Agarwal, Aayush (2024). "Mapping India's Linguistic Diversity and Exclusion in the Indian Census 1". In Dodd, Maya; Menon, Nirmala (eds.). *Practices of Digital Humanities in India: Learning by Doing*. Routledge India. doi:10.4324/9781003325239. ISBN 978-1-003-32523-9.
1. Moseley, Christopher (10 March 2008). *Encyclopedia of the World's Endangered Languages*. Routledge. ISBN 978-1-135-79640-2.
1. Lerner, Hanna (2016). "The Indian Founding: A Comparative Perspective". In Choudhry, Sujit; Khosla, Madhav; Mehta, Pratap Bhanu (eds.). *The Oxford Handbook of the Indian Constitution*. Oxford University Press. pp. 63–64. ISBN 978-0-19-870489-8. Ultimately, it was the pragmatic consensus-seeking approach that triumphed. On 14 September 1949, after three years of debate, the assembly overwhelmingly approved a compromise resolution, known as the Munshi—Ayyangar formula, which later became Articles 343-51 of the Indian Constitution. Instead of declaring a 'national language', Hindi was labelled the 'official language of the Union', while English was to continue to be used 'for all official purposes'. It was decided that this arrangement would apply for a period of fifteen years, during which time Hindi was to be progressively introduced into official use. What would happen at the end of this interim period was left undetermined, with the Constitution providing for the establishment of a parliamentary committee to examine the issue in the future. In addition, the Constitution recognised fourteen other languages for official use (listed in the Eighth Schedule of the Constitution).... Fifteen years after the enactment of the Constitution, Hindi was still not widely used by the Union government. Following a series of violent riots in non-Hindi-speaking States in the 1960s, Parliament renounced the ideal of an Indian national language. In 1965, when the fifteen-year interim period prescribed by the Constitution elapsed, the government announced that English would remain the de facto formal language of India.
1. Isaka, Riho (2021). *Language, Identity, and Power in Modern India: Gujarat, c. 1850–1960*. Routledge New Horizons in South Asian Studies. Routledge. pp. 126–197. ISBN 978-1-000-46858-8. Partition may have 'killed' Hindustani, but it had a marked effect on the debates regarding the position of English and provincial languages in the Constitution. The Hindi protagonists became even more insistent on establishing Hindi as the sole national language and imposing it on the non-Hindi-speaking regions to enhance 'national unity'. In addition, these leaders even began to argue that the Devanagari form of numerals should be used instead of the international form. This was firmly opposed by members from South India. To solve the continuing dispute among the Assembly members, (K. M.) Munshi and N. Gopalaswami Ayyangar, a Tamil member of the Assembly, drew up detailed language provisions. These, in the words of the latter, represented a 'compromise between opinions not easily reconcilable' (Constituent Assembly Debates 1X 1966: 1319). The provisions were proposed to the Congress on 2nd September 1949 and engendered a heated discussion. It was eventually decided that they would be proposed in the Assembly by Munshi, Ayyangar, and Bhimrao Ambedkar (the Chairman of the Drafting Committee) in their personal capacities, not as an official proposal on behalf of the Drafting Committee.
1. Forrester, Duncan B. (1966). "The Madras Anti-Hindi Agitation, 1965: Political Protest and its Effects on Language Policy in India". *Pacific Affairs*. **39** (1/2): 19–36. doi:10.2307/2755179. ISSN 0030-851X. JSTOR 2755179.
1. Sharma, Sandipan (26 January 2026). "1965: When Republic Day became a morning of mourning in Madras". *India Today*. Retrieved 19 April 2026.
1. Annamalai, E. (2008). "Contexts of multilingualism". In Braj B. Kachru; Yamuna Kachru; S. N. Sridhar (eds.). *Language in South Asia*. Cambridge University Press. pp. 223–. ISBN 978-1-139-46550-2. Some of the migrated languages... such as Sanskrit and English, remained primarily as a second language, even though their native speakers were lost.
1. Gazzola, Michele; Wickström, Bengt-Arne (2016). *The Economics of Language Policy*. MIT Press. pp. 469–. ISBN 978-0-262-03470-8. The Eighth Schedule recognizes India's national languages as including the major regional languages as well as others, such as Sanskrit and Urdu, which contribute to India's cultural heritage.... The original list of fourteen languages in the Eighth Schedule at the time of the adoption of the Constitution in 1949 has now grown to twenty-two.
1. Groff, Cynthia (2017). *The Ecology of Language in Multilingual India: Voices of Women and Educators in the Himalayan Foothills*. Palgrave Macmillan UK. pp. 58–. ISBN 978-1-137-51961-0. As Mahapatra says: "It is generally believed that the significance for the Eighth Schedule lies in providing a list of languages from which Hindi is directed to draw the appropriate forms, style and expressions for its enrichment"... Being recognized in the Constitution, however, has had significant relevance for a language's status and functions.
1. Gautam, Vanya (5 January 2024). *Did You Know? Indian Rupee Notes Feature 15 Languages, Here's The List*. India Times.
1. "India has 79.8% Hindus, 14.2% Muslims, says 2011 census data on religion". *Firstpost*. 26 August 2016. Archived from the original on 26 April 2020. Retrieved 14 August 2016.
1. Smith 2008, p. 94.
1. "Preamble To The Indian Constitution". *legalserviceindia.com*.
1. "S. R. Bommai v. Union of India". *www.legalserviceindia.com*. Archived from the original on 28 November 2025. Retrieved 23 November 2025.
1. Basu, Durga Das (2013). *Introduction to the Constitution of India* (21 ed.). LexisNexis. p. 124. ISBN 978-81-803-8918-4.
1. Provisional Population Totals Paper 1 of 2011 India, p. 163.
1. Pathania, Rajni (January 2020). "Literacy in India: Progress and Inequality" (PDF). *bangladeshsociology.org*. **17** (1). Bangladesh e-Journal of Sociology. Archived (PDF) from the original on 10 October 2021. Retrieved 18 October 2021.
1. Natarajan, Dandapani (1971). "Extracts from the All India Census Reports on Literacy" (PDF). Office of the Registrar General & Census Commissioner, India. Archived (PDF) from the original on 28 June 2021. Retrieved 18 October 2021.
1. Chaudhary, Latika (March 2009). "Determinants of Primary Schooling in British India". *The Journal of Economic History*. **69** (1): 269–302. doi:10.1017/S0022050709000400.
1. "Study in India". *studyinindia.gov.in*. Archived from the original on 27 June 2021. Retrieved 18 October 2021.
1. "HRD to increase nearly 25 pc seats in varsities to implement 10 pc quota for poor in gen category". *The Economic Times*. 15 January 2019. Archived from the original on 16 April 2019. Retrieved 18 October 2021.
1. "UDISE+ Dashboard". *dashboard.udiseplus.gov.in*. Ministry of Education. Archived from the original on 18 October 2021. Retrieved 18 October 2021.
1. "India achieves 27% decline in poverty". *Press Trust of India via Sify.com*. 12 September 2008. Archived from the original on 20 February 2014. Retrieved 18 October 2021.
1. N. Jayapalan (2005). *History of Education in India*. Atlantic Publishers & Distributors. ISBN 978-81-7156-922-9.
1. Headrick, Daniel R. (1988). *The Tentacles of Progress: Technology Transfer in the Age of Imperialism, 1850–1940*. New York: Oxford University Press. p. 317. ISBN 0-19-505115-7. The first engineering college was an outgrowth of the Ganges Canal. Named after the lieutenant governor of the North-Western Provinces who founded it in 1847, the Thomason Engineering College at Roorkee trained employees for the irrigation branch of the Public Works Department. It offered different curricula for different types of students: an engineering class for domiciled Europeans and a few Indians, an upper subordinates class to train British noncommissioned officers as construction foremen, and a lower subordinates class to train Indian surveyors. By the mid-1880s, the school has a hundred students, substantial buildings, and a reputation as an important center for the study of hydraulic engineering.
1. Subramanian, Ajantha (2019). *The Caste of Merit: Engineering Education in India*. Cambridge, MA and London: Harvard University Press. pp. 30–31. ISBN 978-0-674-98788-3. Before the 1854 despatch, there was already one engineering college in operation: the Thomason College of Civil Engineering at Roorkee.
1. Chan, Margaret (11 February 2014). *Address at the 'India celebrates triumph over polio' event*. New Delhi, India: World Health Organization. Archived from the original on 17 October 2021. Retrieved 17 October 2021.
1. "Global Tuberculosis Report 2024 - 1.1 TB incidence". *World Health Organization*. 14 September 2024. Retrieved 23 August 2025.
1. Chauhan, Arohi; Parmar, Malik; Dash, Girish Chandra; Solanki, Hardik; Chauhan, Sandeep; Sharma, Jessica; Sahoo, Krushna Chandra; Mahapatra, Pranab; Rao, Raghuram; Kumar, Ravinder; Rade, Kirankumar; Pati, Sanghamitra (3 May 2023). "The prevalence of tuberculosis infection in India: A systematic review and meta-analysis". *Indian Journal of Medical Research*. **157** (2–3): 135–151. doi:10.4103/ijmr.ijmr_382_23. PMC 10319385. PMID 37202933.
1. "204 of 238 Indian cities did not meet air quality standards: CREA". *thehindu.com*. Retrieved 7 March 2026.
1. "Dirty air: how India became the most polluted country on earth". *Financial Times*. 11 December 2018. Archived from the original on 30 September 2019. Retrieved 22 January 2019.
 - Lagasse, Paul, ed. (2007). "Caste". *The Columbia Encyclopedia*. New York, NY: Columbia University Press. ISBN 978-0-231-14446-9. Archived from the original on 1 October 2023. Retrieved 24 September 2012. Quote: "**caste** [Port., casta=basket], ranked groups based on heredity within rigid systems of social stratification, especially those that constitute Hindu India. Some scholars, in fact, deny that true caste systems are found outside India. The caste is a closed group whose members are severely restricted in their choice of occupation and degree of social participation. Marriage outside the caste is prohibited. Social status is determined by the caste of one's birth and may only rarely be transcended."
 - Madan, T. N. (2012). *caste*. Encyclopædia Britannica Online. Archived from the original on 30 January 2013. Retrieved 23 November 2025. Quote: "**caste**, any of the ranked, hereditary, endogamous social groups, often linked with occupation, that together constitute traditional societies in South Asia, particularly among Hindus in India. Although sometimes used to designate similar groups in other societies, the "caste system" is uniquely developed in Hindu societies."
 - Gupta, Dipankar (2008). "Caste". In Schaefer, Richard T. (ed.). *Encyclopedia of Race, Ethnicity, and Society*. Thousand Oaks: SAGE. pp. 246–250. ISBN 978-1-4129-2694-2. Retrieved 5 August 2012. Quote: "**Caste**: What makes Indian society unique is the phenomenon of caste. Economic, religious, and linguistic differentiations, even race-based discrimination, are known elsewhere, but nowhere else does one see caste but in India."
 - Béteille 2002, pp. 136–137. Quote: "**Caste**: Caste has been described as the fundamental social institution of India. Sometimes the term is used metaphorically to refer to rigid social distinctions or extreme social exclusiveness wherever found, and some authorities have used the term 'colour-caste system' to describe the stratification based on race in the United States and elsewhere. But it is among the Hindus in India that we find the system in its most fully developed form although analogous forms exist among Muslims, Christians. Sikhs and other religious groups in South Asia. It is an ancient institution, having existed for at least 2,000 years among the Hindus who developed not only elaborate caste practices hut also a complex theory to explain and justify those practices (Dumont 1970). The theory has now lost much of its force although many of the practices continue."
 - Mitchell, Geoffrey Duncan (2006). "Castes (part of SOCIAL STRATIFICATION)". *A New Dictionary of the Social Sciences*. New Brunswick, NJ: Aldine Transaction Publishers. pp. 194–195. ISBN 978-0-202-30878-4. Retrieved 10 August 2012. Quote:"**Castes** A pure caste system is rooted in the religious order and may be thought of as a hierarchy of hereditary, endogamous, occupational groups with positions fixed and mobility barred by ritual distances between each caste. Empirically, the classical Hindu system of India approximated most closely to pure caste. The system existed for some 3,000 years and continues today despite many attempts to get rid of some of its restrictions. It is essentially connected with Hinduism."
 - "caste, n.". *Oxford English Dictionary, Second edition; online version June 2012*. Oxford, UK: Oxford University Press. 1989. Archived from the original on 24 September 2015. Retrieved 5 August 2019. Quote: "**caste, n.** 2a. spec. One of the several hereditary classes into which society in India has from time immemorial been divided;... *This is now the leading sense, which influences all others*."

1. Atrey, Shreya (2019). *Intersectional Discrimination*. Oxford, UK and New York, NY: Oxford University Press. p. 63–64. ISBN 978-0-19-884895-0.
1. "Indians Outlaw 'Untouchability' In Formal Action by Assembly; UNTOUCHABILITY' FORMALLY BANNED". Reuters/New York Times. 30 April 1947. NEW DELHI, India, April 29 -- India's Constituent Assembly, discussing the Fundamental Rights Committee's report, today adopted this provision: "Untouchability in any form is abolished and the imposition of any disability on that account shall be an offense.
1. Teltumbde, Anand (2010). *The Persistence of Caste: The Khairlanji Murders and India's Hidden Apartheid*. Bloomsbury Academic. ISBN 978-1-84813-449-2.
1. Taylor, Sarah (28 June 2022). "The struggle to challenge India's caste system remains real, still". *ABC*. Archived from the original on 13 July 2024. Retrieved 11 July 2025.
1. Makar 2007.
1. Medora 2003.
1. Jones & Ramdas 2005, p. 111.
1. Biswas, Soutik (29 September 2016). "What divorce and separation tell us about modern India". BBC News. Archived from the original on 21 March 2021. Retrieved 18 October 2021.
1. Cullen-Dupont 2009, p. 96.
1. Agarwal, Bina (1994). *A Field of One's Own: Gender and Land Rights in South Asia*. Cambridge University Press. p. 264. ISBN 978-0-521-42926-9. Mayer's (1960: 219) observation for central India would not be inaccurate for most communities in the subcontinent: "A man's tie with his sister is accounted very close. The two have grown up together, at an age when there is no distinction made between the sexes. And later, when the sister marries, the brother is seen as her main protector, for when her father has died to whom else can she turn if there is trouble in her conjugal household.(Adrian C. Mayer, *Caste and kinship in Central India* (1960)" The parental home, and after the parents' death the brother's home, often offers the only possibility of temporary or longer-term support in case of divorce, desertion, and even widowhood, especially for a woman without adult sons. Her dependence on this support is directly related to economic and social vulnerability.
1. Coleman, Leo (2017). *A Moral Technology: Electrification as Political Ritual in New Delhi*. Cornell University Press. p. 127. ISBN 978-1-5017-0791-9. Quote: Rakhi and its local performances in Kishan Garhi were part of a festival in which connections between out-marrying sisters and village-resident brothers were affirmed. In the "traditional" form of this rite, according to Marriott, sisters exchanged with their brothers to ensure their ability to have recourse—at a crisis, or during childbearing—to their natal village and their relatives there even after leaving for their husband's home. For their part, brothers engaging in these exchanges affirmed the otherwise hard-to-discern moral solidarity of the natal family, even after their sister's marriage.
1. Rowland 1970, pp. 185–198, 252, 385–466.
1. Craven 1997, pp. 14–16.
1. Harle 1994, pp. 17–18.
1. Rowland 1970, pp. 46–47.
1. Craven 1997, pp. 35–46.
1. Rowland 1970, pp. 67–70.
1. Harle 1994, pp. 22–24.
1. Craven 1997, pp. 22, 88.
1. Rowland 1970, pp. 35, 99–100.
1. Craven 1997, pp. 18–19.
1. Blurton 1993, p. 151.
1. Harle 1994, pp. 32–38.
1. Harle 1994, pp. 43–55.
1. Rowland 1970, pp. 113–119.
1. Blurton 1993, pp. 10–11.
1. Craven 1997, pp. 111–121.
1. Michell 2000, pp. 44–70.
1. Harle 1994, pp. 212–216.
1. Craven 1997, pp. 152–160.
1. Blurton 1993, pp. 225–227.
1. Harle 1994, pp. 356–361.
1. Rowland 1970, pp. 242–251.
1. Harle 1994, pp. 361–370.
1. Craven 1997, pp. 202–208.
1. Harle 1994, pp. 372–382, 400–406.
1. Craven 1997, pp. 222–243.
1. Harle 1994, pp. 384–397, 407–420.
1. Craven 1997, p. 243.
1. Michell 2000, p. 210.
1. Michell 2000, pp. 210–211.
1. Blurton 1993, p. 211.
1. Hayashi 2005, p. 363
1. Plofker 2007, p. 1
1. Filliozat 2004, pp. 140–143
1. Hayashi 1995
1. Plofker 2007, p. 6
1. Ifrah 2000, p. 346: "The measure of the genius of Indian civilisation, to which we owe our modern (number) system, is all the greater in that it was the only one in all history to have achieved this triumph. Some cultures succeeded, earlier than the Indian, in discovering one or at best two of the characteristics of this intellectual feat. But none of them managed to bring together into a complete and coherent system the necessary and sufficient conditions for a number-system with the same potential as our own."
1. Plofker 2009, pp. 44–47
1. Bourbaki 1998, p. 46: "...our decimal system, which (by the agency of the Arabs) is derived from Hindu mathematics, where its use is attested already from the first centuries of our era. It must be noted moreover that the conception of zero as a number and not as a simple symbol of separation) and its introduction into calculations, also count amongst the original contribution of the Hindus."
1. Bourbaki 1998, p. 49: Modern arithmetic was known during medieval times as "Modus Indorum" or method of the Indians. Leonardo of Pisa wrote that compared to method of the Indians all other methods is a mistake. This method of the Indians is none other than our very simple arithmetic of addition, subtraction, multiplication and division. Rules for these four simple procedures was first written down by Brahmagupta during the 7th century AD. "On this point, the Hindus are already conscious of the interpretation that negative numbers must have in certain cases (a debt in a commercial problem, for instance). In the following centuries, as there is a diffusion into the West (by intermediary of the Arabs) of the methods and results of Greek and Hindu mathematics, one becomes more used to the handling of these numbers, and one begins to have other "representation" for them which are geometric or dynamic."
1. "algebra" 2007. *Britannica Concise Encyclopedia* Archived 29 September 2007 at the Wayback Machine. Encyclopædia Britannica Online. 16 May 2007. Quote: "A full-fledged decimal, positional system certainly existed in India by the 9th century (AD), yet many of its central ideas had been transmitted well before that time to China and the Islamic world. Indian arithmetic, moreover, developed consistent and correct rules for operating with positive and negative numbers and for treating zero like any other number, even in problematic contexts such as division. Several hundred years passed before European mathematicians fully integrated such ideas into the developing discipline of algebra."
1. Pingree 2003, p. 45 Quote: "Geometry, and its branch trigonometry, was the mathematics Indian astronomers used most frequently. Greek mathematicians used the full chord and never imagined the half chord that we use today. Half chord was first used by Aryabhata which made trigonometry much more simple. In fact, the Indian astronomers in the third or fourth century, using a pre-Ptolemaic Greek table of chords, produced tables of sines and versines, from which it was trivial to derive cosines. This new system of trigonometry, produced in India, was transmitted to the Arabs in the late eighth century and by them, in an expanded form, to the Latin West and the Byzantine East in the twelfth century."
1. Bourbaki 1998, p. 126: "As for trigonometry, it is disdained by geometers and abandoned to surveyors and astronomers; it is these latter (Aristarchus, Hipparchus, Ptolemy) who establish the fundamental relations between the sides and angles of a right angled triangle (plane or spherical) and draw up the first tables (they consist of tables giving the *chord* of the arc cut out by an angle {\displaystyle \theta <\pi } on a circle of radius *r*, in other words the number {\displaystyle 2r\sin \left(\theta /2\right)}; the introduction of the sine, more easily handled, is due to Hindu mathematicians of the Middle Ages)."
1. Stillwell 2004, p. 173
1. Hardy, G. H. (2015). "Notice". *Collected papers of Srinivasa Ramanujan*. Cambridge University Press. pp. xxi–xxxv. ISBN 978-1-107-53651-7. It was his insight into algebraical formulae, transformation of infinite series,... that was most amazing. On this side most certainly I have never met his equal, and I can compare him only with Euler and Jacobi. He worked, far more than the majority of modern mathematicians, by induction from numerical examples.... But with his memory, his patience, and his power of calculation, he combined a power of generalisation, a feeling for form, and a capacity for rapid modification of his hypotheses, that were often really startling, and made him, in his own peculiar field, without a rival in his day.
1. Capwell, Charles (2012). "The Music of India". *Excursions in World Music* (6th ed.). Pearson. pp. 31, 52.
1. Lavezzoli, Peter (24 April 2006). *The Dawn of Indian Music in the West*. p. 14.
1. Sarrazin, Natalie (2019). *Focus: Popular Music in Contemporary India*. Taylor & Francis. ISBN 978-0-429-99931-4.
1. Vatsyayan, Kapila; Lord, Maria (revision) (2020). "India, subcontinent of, IX. Dance". *Grove Music Online*. Oxford University Press.
1. Bishnupriya Dutt; Urmimala Sarkar Munsi (2010). *Engendering Performance: Indian Women Performers in Search of an Identity*. SAGE Publications. p. 216. ISBN 978-81-321-0612-8.
1. Frank Burch Brown (2013). *The Oxford Handbook of Religion and the Arts*. Oxford University Press. pp. 195–196. ISBN 978-0-19-972103-0., Quote: All of the dances considered to be part of the Indian classical canon (Bharata Natyam, Chhau, Kathak, Kathakali, Kuchipudi, Manipuri, Mohiniattam, Odissi, Sattriya, and Yakshagana) trace their roots to religious practices (...) the Indian diaspora has led to the translocation of Hindu dances to Europe, North America and the world."
1. Tarlo 1996, p. 26
1. Tarlo 1996, pp. 26–28
1. Alkazi, Roshen (2002). "Evolution of Indian Costume as a result of the links between Central Asia and India in ancient and medieval times". In Rahman, Abdur (ed.). *India's Interaction with China, Central and West Asia*. Oxford University Press. pp. 464–484. ISBN 978-0-19-565789-0.
1. Stevenson, Angus; Waite, Maurice (2011). *Concise Oxford English Dictionary: Book & CD-ROM Set*. Oxford University Press. p. 1272. ISBN 978-0-19-960110-3. Retrieved 3 September 2019.
1. Stevenson, Angus; Waite, Maurice (2011). *Concise Oxford English Dictionary: Book & CD-ROM Set*. Oxford University Press. p. 774. ISBN 978-0-19-960110-3.
1. Platts, John T. (John Thompson) (1884). *A dictionary of Urdu, classical Hindi, and English*. London: W. H. Allen & Co. p. 418. Archived from the original on 24 February 2021. Retrieved 26 August 2019. (online; updated February 2015)
1. Shukla, Pravina (2015). *The Grace of Four Moons: Dress, Adornment, and the Art of the Body in Modern India*. Indiana University Press. p. 71. ISBN 978-0-253-02121-2.
1. Dwyer, Rachel (2014). *Bollywood's India: Hindi Cinema as a Guide to Contemporary India*. Reaktion Books. pp. 244–245. ISBN 978-1-78023-304-8.
1. Haripriya, Soibam (2024). "Irom Sharmila's Poetry and the Problem of Anthologizing Indian Literature". In Anjaria, Ulka; Nerleker, Anjali= (eds.). *The Oxford Handbook of Modern Indian Literatures*. Oxford University Press. p. 423. ISBN 978-0-19-764791-2.
1. Kohli, Megha (2023). "Breads". In Taylor Sen, Colleen; Bhattacharyya, Sourish; Saberi, Helen (eds.). *The Blooomsbury Handbook of Indian Cuisine*. London, New York, and Dublin: Bloomsbury Publishing. p. 60. ISBN 978-1-3501-2863-7. *Khamiri roti* is the Indian version of sourdough bread. "Khamir" means yeast or starter in Urdu.... It is made in a tandoor.... The culture of purchasaing breads from outside is Central Asian and came to India with the Mughals. The best *khamiri roti* is sold in various shops in Old Delhi run by people who claim to be the direct descendants of the cooks who worked for the Mughals and use the same recipe as their ancestors.
1. Panjabi, Camellia (1995). *The Great Curries of India*. Simon and Schuster. pp. 158–. ISBN 978-0-684-80383-8. The Muslim influenced breads of India are leavened, like *naan*, *Khamiri roti*,...
1. Davidson, Alan (2014). *The Oxford Companion to Food*. Oxford University Press. p. 409. ISBN 978-0-19-967733-7.
1. Davidson, Alan (2014). *The Oxford Companion to Food*. Oxford University Press. p. 161. ISBN 978-0-19-967733-7. Chapatis are made from finely milled whole-wheat flour, called chapati flour or atta, and water. The dough is rolled into thin rounds which vary in size from region to region and then cooked without fat or oil on a slightly curved griddle called a tava.
1. Tamang, J. P.; Fleet, G. H. (2009). "Yeasts Diversity in Fermented Foods and Beverages". In Satyanarayana, T.; Kunze, G. (eds.). *Yeast Biotechnology: Diversity and Applications*. Springer. p. 180. ISBN 978-1-4020-8292-4. Idli is an acid-leavened and steamed cake made by bacterial fermentation of a thick batter made from coarsely ground rice and dehulled black gram. Idli cakes are soft, moist and spongy, have desirable sour flavour, and is eaten as breakfast in South India. Dosa batter is very similar to idli batter, except that both the rice and black gram are finely grounded. The batter is thinner than that of idli and is fried as a thin, crisp pancake and eaten directly in South India.
1. Jhala, Angma Day (2015). *Royal Patronage, Power and Aesthetics in Princely India*. Routledge. p. 70. ISBN 978-1-317-31657-2. With the ascent of the Mughal Empire in sixteenth-century India, Turkic, Persian and Afghan traditions of dress, 'architecture and cuisine' were adopted by non-Muslim indigenous elites in South Asia. In this manner, Central Asian cooking merged with older traditions within the subcontinent, to create such signature dishes as biryani (a fusion of the Persian pilau and the spice-laden dishes of Hindustan), and the Kashmiri meat stew of Rogan Josh. It not only generated new dishes and entire cuisines, but also fostered novel modes of eating. Such newer trends included the consumption of Persian condiments, which relied heavily on almonds, pastries and quince jams, alongside Indian achars made from sweet limes, green vegetables and curds as side relishes during Mughlai meals.
1. Davidson, Alan (2014). *The Oxford Companion to Food*. Oxford University Press. p. 410. ISBN 978-0-19-967733-7.
1. Biswas, Soutik (4 April 2018). "The myth of the Indian vegetarian nation". *BBC*. Archived from the original on 8 August 2018. Retrieved 16 July 2025.
1. "Religion in India: Tolerance and Segregation | Religion and food". *Pew Research Center*. 29 June 2021.
1. Sahakian, Marlyne; Saloma, Czarina; Erkman, Suren (2016). *Food Consumption in the City: Practices and patterns in urban Asia and the Pacific*. Taylor & Francis. p. 50. ISBN 978-1-317-31050-1.
1. Collingham, Elizabeth M. (2007). *Curry: A Tale of Cooks and Conquerors*. Oxford University Press. p. 25. ISBN 978-0-19-532001-5.
1. Roger 2000.
1. Sengupta, Jayanta (2014). "India". In Freedman, Paul; Chaplin, Joyce E.; Albala, Ken (eds.). *Food in Time and Place: The American Historical Association Companion to Food History*. University of California Press. p. 74. ISBN 978-0-520-27745-8.
1. Nandy, Ashis (2004). "The Changing Popular Culture of Indian Food: Preliminary Notes". *South Asia Research*. **24** (1): 9–19. doi:10.1177/0262728004042760.
1. Haidar, Sakina; Hussain, Sajjad; Naz, Safina; Ali, Sajid; Noor, Anam (2025). "Introduction and History of Mango". In Hussain, Sajjad; Nahar, Kamrun; Rajwana, Ishtiaq A.; Ercisli, Sezai; Ahmad, Shakeel (eds.). *Handbook of Research on Mango Fruit: Postharvest Science, Production, Nutrition, and Processing Technology*. CRC Press, Routledge. p. 1–2. ISBN 978-1-77964-338-4.
1. Kuhn, David N.; Bally, Ian S. E.; Dillon, Natalie L.; Innes, David; Groh, Amy M.; Rahaman, Jordon; Ophir, Ron; Cohen, Yuval; Sherman, Amir (20 April 2017). "Genetic Map of Mango: A Tool for Mango Breeding". *Frontiers in Plant Science*. **8** 577. Bibcode:2017FrPS....8..577K. doi:10.3389/fpls.2017.00577. PMC 5397511. PMID 28473837.
1. Warschefsky, Emily J.; Wettberg, Eric J. B. (June 2019). "Population genomic analysis of mango (*Mangifera indica*) suggests a complex history of domestication". *New Phytologist*. **222** (4): 2023–2037. Bibcode:2019NewPh.222.2023W. doi:10.1111/nph.15731. PMID 30730057.
1. Wolpert 2003, p. 2.
1. Rediff 2008 b.
1. "Candidates' R13: Anand Draws, Clinches Rematch with Carlsen". Archived from the original on 11 January 2015. Retrieved 14 December 2018.
1. Binmore 2007, p. 98.
1. Shores, Lori (15 February 2007). *Teens in India*. Compass Point Books. p. 78. ISBN 978-0-7565-2063-2. Archived from the original on 17 June 2012. Retrieved 24 July 2011.
1. Das, Ranit (14 August 2017). "What India was crazy about: Hockey first, Cricket later, Football, Kabaddi now?". *India Today*. Archived from the original on 4 January 2023. Retrieved 2 March 2025.
1. Graham, Bryan Armen (12 December 2024). "Gukesh Dommaraju becomes youngest world chess champion after horrific Ding Liren blunder". *The Guardian*.

## Bibliography

### Overview

- "India". *The World Factbook*. Central Intelligence Agency. Archived from the original on 11 January 2021. Retrieved 10 July 2021.
- "Country Profile: India" (PDF). *Library of Congress Country Studies* (5th ed.). Library of Congress Federal Research Division. December 2004. Archived from the original (PDF) on 27 September 2011. Retrieved 30 September 2011.
- Heitzman, James; Worden, Robert L. (1996). *India: A Country Study*. Area Handbook Series. Washington, D.C.: Library of Congress. ISBN 978-0-8444-0833-0.
- *Provisional Population Totals Paper 1 of 2011 India*. Office of the Registrar General and Census Commissioner. Archived from the original on 9 September 2021. Retrieved 18 October 2021.
- Robinson, Francis, ed. *The Cambridge Encyclopedia of India, Pakistan, Bangladesh, Sri Lanka, Nepal, Bhutan and the Maldives* (1989)
- *Constituent Assembly of India – Volume XII*. National Informatics Centre, Government of India. 24 January 1950. Archived from the original on 21 July 2011. Retrieved 17 July 2011.

### Etymology

- Barrow, Ian J. (2003). "From Hindustan to India: Naming change in changing names". *South Asia: Journal of South Asian Studies*. **26** (1): 37–49. doi:10.1080/085640032000063977.
- Clémentin-Ojha, Catherine (2014). "'India, that is Bharat...': One Country, Two Names". *South Asia Multidisciplinary Academic Journal*. **10**. doi:10.4000/samaj.3717. Archived from the original on 28 September 2015.
- Thieme, P. (1970). "Sanskrit *sindu-/Sindhu-* and Old Iranian *hindu-/Hindu-*". In Mary Boyce; Ilya Gershevitch (eds.). *W. B. Henning Memorial Volume*. Lund Humphries. ISBN 978-0-85331-255-0.

### History

- Asher, C. B.; Talbot, C. (2006). *India Before Europe*. Cambridge University Press. ISBN 978-0-521-80904-7.
- Asher, C. B.; Talbot, C. (2008). *India Before Europe t*. Cambridge University Press. ISBN 978-0-521-51750-8.
- Asher, C. B.; Talbot, C. (2022). *India Before Europe*. Cambridge University Press. ISBN 978-1-108-42816-3.
- Brown, J. M. (1994). *Modern India: The Origins of an Asian Democracy*. The Short Oxford History of the Modern World (2nd ed.). Oxford University Press. ISBN 978-0-19-873113-9.
- Coningham, Robin; Young, Ruth (2015). *The Archaeology of South Asia: From the Indus to Asoka, c. 6500 BCE – 200 CE*. Cambridge University Press. ISBN 978-0-521-84697-4.
- Copland, I. (2001). *India 1885–1947: The Unmaking of an Empire*. Longman. ISBN 978-0-582-38173-5.
- Doniger, Wendy (2014). *On Hinduism*. Oxford University Press. pp. xviii, 10. ISBN 978-0-19-936009-3.
- Elverskog, Johan (2020). *The Buddha's Footprint: An Environmental History of Asia*. Philadelphia: University of Pennsylvania Press. ISBN 978-0-8122-5183-8.
- Flood, Gavin D. (1996). *An Introduction to Hinduism*. Cambridge University Press. ISBN 978-0-521-43878-0.
- Gilbert, Marc Jason (2017). *South Asia in World History*. The New Oxford World History series. Oxford University Press. pp. 54–56. ISBN 978-0-19-517653-7.
- Judd, Denis (2004). *The Lion and the Tiger: The Rise and Fall of the British Raj, 1600–1947*. Oxford and New York: Oxford University Press. Pp. xiii, 280. ISBN 978-0-19-280358-0.
- Kulke, H.; Rothermund, D. (2004). *A History of India*. 4th. Routledge. ISBN 978-0-415-32920-0.
- Kulke, H.; Rothermund, D. (2016). *A History of India*. 6th. Routledge. ISBN 978-1-138-96114-2.
- Lowe, John J. (2015). *Participles in Rigvedic Sanskrit: The Syntax and Semantics of Adjectival Verb Forms*. Oxford University Press. ISBN 978-0-19-100505-3.
- Ludden, D. (2002). *India and South Asia: A Short History*. Oneworld Publications. ISBN 978-1-85168-237-9.
- Ludden, D. (2014). *India and South Asia: A Short History* (2nd, revised ed.). Oneworld Publications. ISBN 978-1-85168-936-1.
- Metcalf, Barbara D.; Metcalf, Thomas R. (2006). *A Concise History of Modern India* (2nd ed.). Cambridge University Press. ISBN 978-0-521-68225-1.
- Metcalf, Barbara D.; Metcalf, Thomas R. (2012). *A Concise History of Modern India*. Cambridge University Press. ISBN 978-1-107-02649-0. Archived from the original on 13 July 2023. Retrieved 13 August 2019.
- Peers, D. M. (2006). *India under Colonial Rule: 1700–1885*. Pearson Longman. ISBN 978-0-582-31738-3.
- Flood, Gavin (2020). "Introduction". In Gavin Flood (ed.). *The Oxford History of Hinduism: Hindu Practice: Hindu Practice*. Oxford University Press. ISBN 978-0-19-105322-1.
- Iori, Elisa (2023). "Releasing Urban Religion beyond the City Wall: The Spatial Capital of Early Buddhist Monasticism in NW South Asia". *Numen*. **70** (2–3): 184–219. doi:10.1163/15685276-20231691. hdl:10278/5079362.
- Jamison, Stephanie; Brereton, Joel (2020). *The Rigveda*. Oxford University Press. ISBN 978-0-19-063339-4.
- Mattern, Susan (2019). *The Slow Moon Climbs: The Science, History, and Meaning of Menopause*. Princeton, NJ, and London: Princeton University Press. ISBN 978-0-691-17163-0.
- Michaels, Axel (2017). Patrick Olivelle, Donald R. Davis (ed.). *The Oxford History of Hinduism: Hindu Law: A New History of Dharmaśāstra*. Oxford: Oxford University Press. ISBN 978-0-19-100709-5.
- Peers, D. M. (2013). *India Under Colonial Rule: 1700–1885*. Routledge. ISBN 978-1-317-88286-2. Retrieved 13 August 2019.
- Petraglia, Michael D.; Allchin, Bridget (2007). "Human evolution and culture change in the Indian subcontinent". In Michael Petraglia; Bridget Allchin (eds.). *The Evolution and History of Human Populations in South Asia: Inter-disciplinary Studies in Archaeology, Biological Anthropology, Linguistics and Genetics*. Springer Publishing. ISBN 978-1-4020-5562-1.
- Possehl, G. (2003). *The Indus Civilization: A Contemporary Perspective*. Rowman Altamira. ISBN 978-0-7591-0172-2.
- Robb, P. (2001). *A History of India*. Palgrave. ISBN 978-0-333-69129-8.
- Robb, P. (2011). *A History of India*. Palgrave Macmillan. ISBN 978-0-230-34549-2.
- Roy, Tirthankar (2012). *India in the World Economy: From Antiquity to the Present*. Cambridge and New York: Cambridge University Press. ISBN 978-1-107-00910-3.
- Sarkar, S. (1983). *Modern India: 1885–1947*. Delhi: Macmillan. ISBN 978-0-333-90425-1.
- Singh, Upinder (2009). *A History of Ancient and Medieval India: From the Stone Age to the 12th Century*. Delhi: Longman. ISBN 978-81-317-1677-9.
- Singh, Upinder (2017). *Political Violence in Ancient India*. Harvard University Press. ISBN 978-0-674-98128-7.
- Spear, Percival (1990). *History of India, Volume 2: From the sixteenth century to the twentieth century*. Penguin. ISBN 978-0-140-13836-8.
- Sripati, V. (1998). "Toward Fifty Years of Constitutionalism and Fundamental Rights in India: Looking Back to See Ahead (1950–2000)". *American University International Law Review*. **14** (2): 413–496.
- Stein, B. (2010). Arnold, D. (ed.). *A History of India* (2nd ed.). Oxford: Wiley-Blackwell. ISBN 978-1-4051-9509-6.
- Witzel, Michael (2003). "Vedas and Upanișads". In Gavin D. Flood (ed.). *The Blackwell companion to Hinduism*. John Wiley & Sons. ISBN 978-0-631-21535-6. Retrieved 15 March 2012.
- Wolpert, S. (2003). *A New History of India* (7th ed.). Oxford University Press. ISBN 978-0-19-516678-1.
- Wright, Rita P. (2010). *The Ancient Indus: Urbanism, Economy, and Society*. Cambridge University Press. ISBN 978-0-521-57219-4. Retrieved 29 September 2013.

### Geography

- Ali, J. R.; Aitchison, J. C. (2005). "Greater India". *Earth-Science Reviews*. **72** (3–4): 170–173. Bibcode:2005ESRv...72..169A. doi:10.1016/j.earscirev.2005.07.005.
- Basu, Mahua; Xavier, Savarimuthu (2017). *Fundamentals of Environmental Studies*. Cambridge University Press. ISBN 978-1-316-87051-8.
- Chang, J. H. (1967). "The Indian Summer Monsoon". *Geographical Review*. **57** (3). American Geographical Society, Wiley: 373–396. Bibcode:1967GeoRv..57..373C. doi:10.2307/212640. JSTOR 212640.
- *Forest (Conservation) Act, 1980 with Amendments Made in 1988* (PDF). Department of Environment and Forests, Government of the Andaman and Nicobar Islands. 1988. Archived from the original (PDF) on 21 July 2011. Retrieved 25 July 2011.
- Dikshit, K. R.; Schwartzberg, Joseph E. (2023). "India: Land". *Encyclopædia Britannica*. pp. 1–29. Archived from the original on 8 May 2015. Retrieved 7 February 2022.
- Duff, D. (1993). *Holmes Principles of Physical Geology* (4th ed.). Routledge. ISBN 978-0-7487-4381-0.
- Frisch, Wolfgang; Meschede, Martin; Blakey, Ronald (2011). *Plate Tectonics: Continental Drift and Mountain Building*. Heidelberg: Springer. doi:10.1007/978-3-540-76504-2. ISBN 978-3-540-76503-5.
- Kaul, R. N. (1970). "The Indian Subcontinent: Indo-Pakistan". In Kaul, R. N. (ed.). *Afforestation in Arid Zones*. The Hague: Dr. W. Junk, N.V., Publishers. ISBN 978-94-010-3352-7.
- Kumar, V. Sanil; Pathak, K. C.; Pednekar, P.; Raju, N. S. N.; Gowthaman, R. (2006). "Coastal processes along the Indian coastline" (PDF). *Current Science*. **91** (4): 530–536. Archived from the original (PDF) on 8 September 2009.
- Mcgrail, Sean; Blue, Lucy; Kentley, Eric; Palmer, Colin (2003). *Boats of South Asia*. Routledge. ISBN 978-1-134-43130-4.
- Molnar, Peter (2015). *Plate Tectonics: A Very Short Introduction*. Oxford University Press. ISBN 978-0-19-872826-9.
- *India Yearbook 2007*. New Delhi: Publications Division, Ministry of Information and Broadcasting, Government of India. 2007. ISBN 978-81-230-1423-4.
- Posey, C. A. (1994). *The Living Earth Book of Wind and Weather*. Reader's Digest. ISBN 978-0-89577-625-9.
- Prakash, B.; Kumar, S.; Rao, M. S.; Giri, S. C. (2000). "Holocene Tectonic Movements and Stress Field in the Western Gangetic Plains" (PDF). *Current Science*. **79** (4): 438–449. Archived (PDF) from the original on 4 May 2011. Retrieved 7 February 2022.
- Prasad, Ishwar (1974). "The Ecology of Vertebrates of the Indian Desert". In Mani, M. S. (ed.). *Ecology and Biogeography in India*. The Hague: Dr. W. Junk bv Publishers. ISBN 978-94-010-2333-7.

### Biodiversity

- Basak, R. K. (1983). *Botanical Survey of India: Account of Its Establishment, Development, and Activities*. India. Department of Environment. Retrieved 20 July 2011.
- Crame, J. A.; Owen, A. W. (2002). *Palaeobiogeography and Biodiversity Change: The Ordovician and Mesozoic–Cenozoic Radiations*. Geological Society Special Publication. Geological Society of London. ISBN 978-1-86239-106-2. Retrieved 8 December 2011.
- Karanth, K. Ullas; Gopal, Rajesh (2005). "An ecology-based policy framework for human-tiger coexistence in India". In Rosie Woodroffe; Simon Thirgood; Alan Rabinowitz (eds.). *People and Wildlife, Conflict Or Co-existence?*. Cambridge University Press. ISBN 978-0-521-53203-7.
- Karanth, K. P. (2006). "Out-of-India Gondwanan Origin of Some Tropical Asian Biota" (PDF). *Current Science*. **90** (6): 789–792. Archived from the original (PDF) on 11 April 2019. Retrieved 18 May 2011.
- Tritsch, M. F. (2001). *Wildlife of India*. London: HarperCollins. ISBN 978-0-00-711062-9.
- World Conservation Monitoring Centre (1994). Groombridge, Brian (ed.). *1994 IUCN Red List of Threatened Animals*. International Union for Conservation of Nature. ISBN 978-2-8317-0194-3.
- *Indian Wildlife (Protection) Act, 1972*. Ministry of Environment and Forests, Government of India. 9 September 1972. Archived from the original on 16 July 2011. Retrieved 25 July 2011.

### Politics

- Banerjee, Sumanta (22 July 2005). "Civilising the BJP". *Economic & Political Weekly*. **40** (29): 3116–3119. JSTOR 4416896.
- Bhambhri, C. P. (1992). *Politics in India, 1991–1992*. Shipra. ISBN 978-81-85402-17-8. Retrieved 20 July 2011.
- Burnell, P. J.; Calvert, P. (1999). *The Resilience of Democracy: Persistent Practice, Durable Idea*. Taylor & Francis. ISBN 978-0-7146-8026-2. Retrieved 20 July 2011.
- India, Press Trust of (16 May 2009). "Second UPA Win, A Crowning Glory for Sonia's Ascendancy". *Business Standard India*. Press Trust of India. Archived from the original on 5 March 2016. Retrieved 13 June 2009.
- Chander, N. J. (2004). *Coalition Politics: The Indian Experience*. Concept Publishing Company. ISBN 978-81-8069-092-1. Retrieved 20 July 2011.
- Dunleavy, P.; Diwakar, R.; Dunleavy, C. (2007). *The Effective Space of Party Competition* (PDF). London School of Economics and Political Science. Archived from the original (PDF) on 28 October 2007. Retrieved 27 September 2011.
- Dutt, S. (1998). "Identities and the Indian State: An Overview". *Third World Quarterly*. **19** (3): 411–434. doi:10.1080/01436599814325.
- Echeverri-Gent, J. (January 2002). "Politics in India's Decentred Polity". In Ayres, A.; Oldenburg, P. (eds.). *Quickening the Pace of Change*. India Briefing. London: M. E. Sharpe. pp. 19–53. ISBN 978-0-7656-0812-3.
- "Current Recognised Parties" (PDF). *Election Commission of India*. 14 March 2009. Archived (PDF) from the original on 9 October 2010. Retrieved 5 July 2010.
- Madhavan, M. R. (2024). "The Lok Sabha". In Ganguly, Sumit; Sridharan, Eshwaran (eds.). *The Oxford Handbook of Indian Politics*. Oxford University Press. ISBN 978-0-19-889428-5.
- Gledhill, A. (1970). *The Republic of India: The Development of its Laws and Constitution*. Greenwood. ISBN 978-0-8371-2813-9. Retrieved 21 July 2011.
- Malik, Yogendra K.; Singh, V. B. (April 1992). "Bharatiya Janata Party: An Alternative to the Congress (I)?". *Asian Survey*. **32** (4): 318–336. doi:10.2307/2645149. JSTOR 2645149.
- Mathew, K. M. (2003). *Manorama Yearbook*. Malayala Manorama. ISBN 978-81-900461-8-3. Retrieved 21 July 2011.
- "National Symbols". *Know India*. National Informatics Centre, Government of India. Archived from the original on 18 April 2021. Retrieved 18 April 2021.
- Neuborne, Burt (2003). "The Supreme Court of India". *International Journal of Constitutional Law*. **1** (3): 476–510. doi:10.1093/icon/1.3.476.
- Pylee, M. V. (2003a). "The Longest Constitutional Document". *Constitutional Government in India* (2nd ed.). S. Chand. ISBN 978-81-219-2203-6.
- Pylee, M. V. (2003b). "The Union Judiciary: The Supreme Court". *Constitutional Government in India* (2nd ed.). S. Chand. ISBN 978-81-219-2203-6. Retrieved 2 November 2007.
- Sarkar, N. I. (2007). *Sonia Gandhi: Tryst with India*. Atlantic. ISBN 978-81-269-0744-1. Retrieved 20 July 2011.
- Sharma, R. (1950). "Cabinet Government in India". *Parliamentary Affairs*. **4** (1): 116–126. doi:10.1093/oxfordjournals.pa.a052755.
- Sharma, B. K. (2007). *Introduction to the Constitution of India* (4th ed.). Prentice Hall. ISBN 978-81-203-3246-1.
- Sinha, A. (2004). "The Changing Political Economy of Federalism in India". *India Review*. **3** (1): 25–63. doi:10.1080/14736480490443085.
- Wheare, K. C. (1980). *Federal Government* (4th ed.). Oxford University Press. ISBN 978-0-313-22702-8.

### Foreign relations and military

- Alford, P. (7 July 2008). "G8 Plus 5 Equals Power Shift". *The Australian*. Retrieved 21 November 2009.
- Behera, L. K. (7 March 2011). *Budgeting for India's Defence: An Analysis of Defence Budget 2011–2012*. Institute for Defence Studies and Analyses. Archived from the original on 3 April 2015. Retrieved 4 April 2011.
- *Russia Agrees India Nuclear Deal*. BBC News. 11 February 2009. Archived from the original on 11 October 2010. Retrieved 22 August 2010.
- Curry, B. (27 June 2010). "Canada Signs Nuclear Deal with India". *The Globe and Mail*. Archived from the original on 25 May 2017. Retrieved 13 May 2011.
- "EU-India Strategic Partnership". *Europa: Summaries of EU Legislation*. European Union. 8 April 2008. Archived from the original on 3 May 2011. Retrieved 14 January 2011.
- Ghosh, A. (2009). *India's Foreign Policy*. Pearson. ISBN 978-81-317-1025-8.
- Gilbert, M. (2002). *A History of the Twentieth Century*. William Morrow. ISBN 978-0-06-050594-3. Retrieved 22 July 2011.
- Kumar, A. V. (1 May 2010). "Reforming the NPT to Include India". *Bulletin of the Atomic Scientists*. Archived from the original on 7 April 2014. Retrieved 1 November 2010.
- Miglani, S. (28 February 2011). "With An Eye on China, India Steps Up Defence Spending". *Reuters*. Archived from the original on 2 May 2011. Retrieved 6 July 2011.
- Nair, V. K. (2007). "No More Ambiguity: India's Nuclear Policy" (PDF). *afsa.org*. Archived from the original (PDF) on 27 September 2007. Retrieved 7 June 2007.
- Pandit, Rajat (27 July 2009). "N-Submarine to Give India Crucial Third Leg of Nuke Triad". *The Times of India*. Archived from the original on 11 August 2011. Retrieved 10 March 2010.
- Pandit, Rajat (8 January 2015). "Make-in-India: Plan to develop 5th-generation fighter aircraft". *The Times of India*. Archived from the original on 11 March 2015. Retrieved 17 October 2021.
- Pandit, Rajat (16 March 2021). "India's weapon imports fell by 33% in last five years but remains world's second-largest arms importer". *The Times of India*. Archived from the original on 7 June 2023. Retrieved 3 February 2022.
- Pandit, Rajat (1 February 2022). "Strong push for indigenous weapons amidst modest hike in defence budget". *The Times of India*. Retrieved 3 February 2022.
- Perkovich, G. (2001). *India's Nuclear Bomb: The Impact on Global Proliferation*. University of California Press. ISBN 978-0-520-23210-5. Retrieved 22 July 2011.
- *India, France Agree on Civil Nuclear Cooperation*. Rediff. 25 January 2008. Archived from the original on 1 May 2011. Retrieved 22 August 2010.
- "UK, India Sign Civil Nuclear Accord". *Reuters*. 13 February 2010. Archived from the original on 12 May 2012. Retrieved 22 August 2010.
- Rothermund, D. (2000). *The Routledge Companion to Decolonization*. Routledge Companions to History. Routledge. ISBN 978-0-415-35632-9.
- Sharma, S. R. (1999). *India–USSR Relations 1947–1971: From Ambivalence to Steadfastness*. Vol. 1. Discovery. ISBN 978-81-7141-486-4.
- Sisodia, N. S.; Naidu, G. V. C. (2005). *Changing Security Dynamic in Eastern Asia: Focus on Japan*. Promilla. ISBN 978-81-86019-52-8.
- "India, US Sign 123 Agreement". *The Times of India*. 11 October 2008. Archived from the original on 7 November 2011. Retrieved 21 July 2011.

### Economy

- Alamgir, J. (2008). *India's Open-Economy Policy: Globalism, Rivalry, Continuity*. Taylor & Francis. ISBN 978-0-415-77684-4. Retrieved 23 July 2011.
- Bonner, B (20 March 2010). "Make Way, World. India Is on the Move". *The Christian Science Monitor*. Archived from the original on 5 August 2011. Retrieved 23 July 2011.
- Farrell, D.; Beinhocker, E. (19 May 2007). *Next Big Spenders: India's Middle Class*. McKinsey & Company. Archived from the original on 5 December 2011. Retrieved 17 September 2011.
- Gargan, E. A. (15 August 1992). "India Stumbles in Rush to a Free Market Economy". *The New York Times*. Archived from the original on 8 February 2011. Retrieved 22 July 2011.
- Hawksworth, John; Tiwari, Anmol (January 2011). *The World in 2050: The Accelerating Shift of Global Economic Power: Challenges and Opportunities* (PDF). PricewaterhouseCoopers. Archived (PDF) from the original on 7 April 2014. Retrieved 23 July 2011.
- Nayak, P. B.; Goldar, B.; Agrawal, P. (2010). *India's Economy and Growth: Essays in Honour of V. K. R. V. Rao*. SAGE Publications. ISBN 978-81-321-0452-0.
- Pal, P.; Ghosh, J (July 2007). "Inequality in India: A Survey of Recent Trends" (PDF). *DESA Working Paper No. 45*. United Nations Department of Economic and Social Affairs. Archived (PDF) from the original on 24 March 2021. Retrieved 23 July 2011.
- Schwab, K. (2010). *The Global Competitiveness Report 2010–2011* (PDF). World Economic Forum. Archived (PDF) from the original on 6 December 2010. Retrieved 10 May 2011.
- Sheth, N. (28 May 2009). "Outlook for Outsourcing Spending Brightens". *The Wall Street Journal*. Archived from the original on 24 March 2021. Retrieved 3 October 2010.
- Yep, E. (27 September 2011). "ReNew Wind Power Gets $201 Million Goldman Investment". *The Wall Street Journal*. Archived from the original on 24 March 2021. Retrieved 27 September 2011.
- "India Second Fastest Growing Auto Market After China". *Business Line*. 10 April 2010. Archived from the original on 30 December 2013. Retrieved 23 July 2011.
- "India world's second largest textiles exporter: UN Comtrade". *The Economic Times*. 2 June 2014. Archived from the original on 5 June 2014. Retrieved 17 October 2021.
- "India's Economy: Not Just Rubies and Polyester Shirts". *The Economist*. 8 October 2011. Archived from the original on 22 October 2018. Retrieved 9 October 2011.
- "Indian Car Exports Surge 36%". *Express India*. 13 October 2009. Archived from the original on 28 April 2016. Retrieved 5 April 2016.
- "Measuring the cost of living worldwide". *The Economist*. 21 March 2017. Archived from the original on 25 May 2017. Retrieved 25 May 2017.
- *Economic Survey of India 2007: Policy Brief* (PDF). Organisation for Economic Co-operation and Development. October 2007. Archived from the original (PDF) on 6 June 2011. Retrieved 22 July 2011.
- *India: Undernourished Children – A Call for Reform and Action*. World Bank. Archived from the original on 7 May 2012. Retrieved 23 July 2011.
- *Indian IT-BPO Industry*. NASSCOM. 2011–2012. Archived from the original on 9 May 2012. Retrieved 22 June 2012.
- *Understanding the WTO: The Organization Members and Observers*. World Trade Organization. 1995. Archived from the original on 29 December 2009. Retrieved 23 June 2012.
- *World Economic Outlook Update*. International Monetary Fund. June 2011. Archived from the original on 1 February 2016. Retrieved 22 July 2011.

### Demographics

- Chandramouli, C. (15 July 2011). *Rural Urban Distribution of Population* (PDF). Ministry of Home Affairs (India). Archived (PDF) from the original on 18 March 2015. Retrieved 24 January 2015.
- Dharwadker, A. (2010). "Representing India's Pasts: Time, Culture, and Problems of Performance Historiography". In Canning, C. M.; Postlewait, T. (eds.). *Representing the Past: Essays in Performance Historiography*. University of Iowa Press. ISBN 978-1-58729-905-6. Retrieved 24 July 2011.
- Drèze, J.; Goyal, A. (2009). "The Future of Mid-Day Meals". In Baru, R. V. (ed.). *School Health Services in India: The Social and Economic Contexts*. SAGE Publications. ISBN 978-81-7829-873-3.
- Dyson, T.; Visaria, P. (2005). "Migration and Urbanisation: Retrospect and Prospects". In Dyson, T.; Casses, R.; Visaria, L. (eds.). *Twenty-First Century India: Population, Economy, Human Development, and the Environment*. Oxford University Press. ISBN 978-0-19-928382-8.
- Dyson, Tim (2018). *A Population History of India: From the First Modern People to the Present Day*. Oxford University Press. ISBN 978-0-19-882905-8. Archived from the original on 25 September 2024. Retrieved 29 July 2019.
- Fisher, Michael H. (2018). *An Environmental History of India: From Earliest Times to the Twenty-First Century*. Cambridge and New York: Cambridge University Press. doi:10.1017/9781316276044. ISBN 978-1-107-11162-2. LCCN 2018021693. Archived from the original on 25 September 2024. Retrieved 29 July 2019.
- Garg, S. C. (19 April 2005). *Mobilizing Urban Infrastructure Finance in India* (PDF). World Bank. Archived from the original (PDF) on 24 August 2009. Retrieved 27 January 2010.
- Mallikarjun, B (November 2004). "Fifty Years of Language Planning for Modern Hindi – The Official Language of India". *Language in India*. **4** (11). Archived from the original on 10 January 2018. Retrieved 24 July 2011.
- Ottenheimer, H. J. (2008). *The Anthropology of Language: An Introduction to Linguistic Anthropology*. Cengage. ISBN 978-0-495-50884-7.
- Ratna, U. (2007). "Interface Between Urban and Rural Development in India". In Dutt, A. K.; Thakur, B. (eds.). *City, Society, and Planning*. Vol. 1. Concept. ISBN 978-81-8069-459-2.
- Rorabacher, J. A. (2010). *Hunger and Poverty in South Asia*. Gyan. ISBN 978-81-212-1027-0.
- Smith, Peter (2008). *An Introduction to the Baha'i Faith*. Cambridge: Cambridge University Press. ISBN 978-0-521-86251-6. Archived from the original on 10 March 2025. Retrieved 1 December 2025.
- *Notification No. 2/8/60-O.L*. Ministry of Home Affairs, Government of India. 27 April 1960. Archived from the original on 1 October 2014. Retrieved 13 May 2011.
- "Census Data 2001". *Office of the Registrar General and Census Commissioner*. Ministry of Home Affairs, Government of India. 2010–2011. Archived from the original on 12 August 2011. Retrieved 22 July 2011.

### Culture

- Asher, Catherine B. (1992). *Architecture of Mughal India*. New Cambridge History of India series. Cambridge; New York: Cambridge University Press. doi:10.1017/CHOL9780521267281. ISBN 978-0-521-26728-1.
- Béteille, André (2002). "Caste". In Barnard, Alan; Spencer, Jonathan (eds.). *Encyclopedia of Social and Cultural Anthropology*. New York; London: Routledge. ISBN 978-0-415-28558-2.
- Binmore, K. G. (2007). *Playing for Real: A Text on Game Theory*. Oxford University Press. ISBN 978-0-19-530057-4.
- Blurton, T. Richard (1993). *Hindu Art*. Harvard University Press. ISBN 978-0-674-39189-5.
- Bourbaki, Nicolas (1998). *Elements of the History of Mathematics*. Berlin, Heidelberg, and New York: Springer-Verlag, 301 pages. ISBN 978-3-540-64767-6.
- Craven, Roy C (1997). *Indian art: a concise history*. New York City: Thames & Hudson. ISBN 978-0-500-20302-6. OCLC 37895110.
- Cullen-Dupont, K. (July 2009). *Human Trafficking*. Infobase Publishing. ISBN 978-0-8160-7545-4.
- Filliozat, Pierre-Sylvain (2004). "Ancient Sanskrit Mathematics: An Oral Tradition and a Written Literature". In Chemla, Karine; Cohen, Robert S.; Renn, Jürgen; et al. (eds.). *History of Science, History of Text (Boston Series in the Philosophy of Science)*. Dordrecht: Springer Netherlands, 254 pages, pp. 137–157. pp. 360–375. doi:10.1007/1-4020-2321-9_7. ISBN 978-1-4020-2320-0..
- Harle, James C. (1994). *The Art and Architecture of the Indian Subcontinent*. Yale University Press. ISBN 978-0-300-06217-5.
- Hayashi, Takao (2005). "Indian Mathematics". In Flood, Gavin (ed.). *The Blackwell Companion to Hinduism*. Oxford: Basil Blackwell, 616 pages, pp. 360–375. pp. 360–375. ISBN 978-1-4051-3251-0..
- Hayashi, Takao (1995). *The Bakhshali Manuscript, An ancient Indian mathematical treatise*. Groningen: Egbert Forsten, 596 pages. ISBN 978-90-6980-087-5..
- Ifrah, Georges (2000). *A Universal History of Numbers: From Prehistory to Computers*. New York: Wiley. ISBN 978-0-471-39340-5.
- Jones, G.; Ramdas, K. (2005). *(Un)tying the Knot: Ideal and Reality in Asian Marriage*. National University of Singapore Press. ISBN 978-981-05-1428-0.
- Kiple, K. F.; Ornelas, K. C., eds. (2000). *The Cambridge World History of Food*. Vol. 2. Cambridge and New York: Cambridge University Press. ISBN 978-0-521-40215-6.
- Kuiper, K., ed. (2010). *The Culture of India*. Britannica Educational Publishing. ISBN 978-1-61530-203-1. Retrieved 24 July 2011.
- Makar, E. M. (2007). *An American's Guide to Doing Business in India*. Adams. ISBN 978-1-59869-211-2.
- Medora, N. (2003). "Mate Selection in Contemporary India: Love Marriages Versus Arranged Marriages". In Hamon, R. R.; Ingoldsby, B. B. (eds.). *Mate Selection Across Cultures*. SAGE Publications. pp. 209–230. ISBN 978-0-7619-2592-7.
- Michell, George (2000). *Hindu Art and Architecture*. Thames & Hudson. ISBN 978-0-500-20337-8.
- Pingree, David (2003). "The logic of non-Western science: mathematical discoveries in medieval India". *Daedalus*. **132** (4): 45–54. doi:10.1162/001152603771338779..
- Plofker, K. (2007). "Mathematics of India". In Katz, Victor J. (ed.). *The Mathematics of Egypt, Mesopotamia, China, India, and Islam: A Sourcebook*. Princeton, NJ: Princeton University Press. pp. 385–514. ISBN 978-0-691-11485-9..
- Plofker, Kim (2009). *Mathematics in India: 500 BCE–1800 CE*. Princeton, NJ: Princeton University Press. ISBN 978-0-691-12067-6..
- Roger, Delphine. "The Middle East and South Asia (in Chapter: History and Culture of Food and Drink in Asia)". In Kiple & Ornelas (2000), pp. 1140–1150.
- Rowland, Benjamin (1970). *The Art and Architecture of India: Buddhist, Hindu, Jain*. Penguin Books. ISBN 978-0-14-056102-9.
- Stillwell, John (2004). *Mathematics and its History*. Undergraduate Texts in Mathematics (2 ed.). Springer, Berlin and New York, 568 pages. doi:10.1007/978-1-4684-9281-1. ISBN 978-0-387-95336-6..
- Tarlo, E. (1996). *Clothing Matters: Dress and Identity in India*. University of Chicago Press. ISBN 978-0-226-78976-7. Retrieved 24 July 2011.
- *Anand Crowned World Champion*. Rediff. 29 October 2008. Archived from the original on 10 October 2017. Retrieved 29 October 2008.

## External links

**Government**

- Official website of the Government of India
- Government of India Web Directory

**General information**

- India Archived 11 January 2021 at the Wayback Machine. *The World Factbook*. Central Intelligence Agency.
- India web resources provided by GovPubs at the University of Colorado Boulder Libraries
- India from BBC News
- Wikimedia Atlas of India
- Geographic data related to India at OpenStreetMap
- Key Development Forecasts for India from International Futures

**; v; t; eIndia topicsRelated topicsAuthority control databases**

21°N 78°E﻿ / ﻿21°N 78°E
